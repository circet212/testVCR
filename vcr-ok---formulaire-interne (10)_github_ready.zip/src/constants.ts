
import { OptionConfig } from './types';

export const OPTIONS: OptionConfig = {
  commDechets: ["Avant", "Après", "Pas déchets"],
  commEtiquette: ["Erronée", "Illisible", "Absente", "Manuscrite"],
  commJarretieres: ["Illisible", "Manuscrite", "Erronée", "Absente"],
  commCable: ["Illisible", "Manuscrite", "Erronée", "Absente", "Non gravée"],
  commRefPb: ["Illisible", "Erronée", "Absente"],
  commFibre: ["Erronée", "Illisible", "Absente"],
  commPhotoPtoPlp: [
    "Jarretière pas complètement visible",
    "PTO non entière",
    "PTO non fixée",
    "Photomètre non présent",
    "Photomètre non réglé sur 1490 ou 1577",
    "Mesure NC"
  ],
  suspicionOpts: ["Pto non fixée", "Photo avant travaux absente", "NC (si PLP > RACC)", "Jarr illisible complètement"],
  pbAvantOpts: ["Absente", "Cassette différente"],
  pbApresOpts: ["Absente", "Illisible", "Erronée"],
  voisinageOpts: ["KO", "Perte puissante", "Absent", "NC"],
  mesureExtra: ["Illisible", "Photomètre non réglé sur 1490 ou 1577", "Absente"]
};

export const DESCRIPTIONS: Record<string, string> = {
  contact: "Avec = Appel entrant / Sans = Stock ou BL",
  presta: "Typologie RDV terrain différente du dossier (tag PLP mais RACC fait ou l'inverse)",
  Val_ROP: "Validation ROP faite (soit avec l'OI ou via eMutation -Reprovisioning à chaud rempli-)",
  desserte: "Type PBO dossier différent du terrain (onglet -PBO Infos complémentaires-)",
  pm_dechets: "Détection de déchets sur les images PM",
  pm_cadrage: "Photo PM affiche tout le PM sans manque de partie",
  pm_ref_jarretieres: "Référence jarritière conforme au dossier",
  pm_mesure: "Mesure PM sur le photomètre conforme avec réglage de fréquence sur 1490 ou 1577",
  pto_conf: "PTO de BYTEL",
  pto_etiquette: "Référence PTO conforme au dossier et imprimé",
  pto_suspicion: "En cas de doute de fraude d'installation PTO",
  pto_mesure_avant: "Mesure PTO avant intervention (Spécifique E2)",
  pto_photo: "En cas de doute de fraude d'installation PTO",
  pto_mesure: "Mesure PTO sur le photomètre conforme (réglage 1490 or 1577)",
  pto_cadrage: "Cadrage correct de la Prise Terminale Optique",
  pbo_ref_cable: "Référence câble client sur le PBO conforme au dossier",
  pbo_ref_pb: "Référence PBO conforme au dossier",
  pbo_avant: ".. Avant raccordement",
  pbo_apres: ".. Après raccordement",
  pbo_cadrage: "PBO bien cadré on l'image",
  pbo_mesure_e2: "Mesure au PBO conforme (Obligatoire en E2)",
  autre_penetration: "Photo de point de pénétration de câble chez le client",
  autre_geoloc: "Toutes les photos géolocalisé et horodatées",
  autre_voisinage: "CV conforme (en OK avec le bon SERVID et FYT client)",
  autre_voisin_perturbe: "Pas de voisin(s) perturbé(s) sur le CheckV",
  autre_sauvage: "Incohérence ROP terrain et ROP dossier ou photos",
  autre_nacelle: "Photo nacelle géolocalisée, horodaté si intervention avec nacelle, sinon NA"
};

export const TYPE_LABELS = {
  RACC: 'RACCORDEMENT',
  PLP: 'PLP',
  PLP_E2: 'PLP E2',
  PLP_E3: 'PLP E3'
};

// Configuration pour le guide visuel
export interface VisualGuideItem {
  id: string;
  title: string;
  description: string;
  cases: { label: string; status: 'ok' | 'ko'; imageUrl: string }[];
}

// Fonction utilitaire pour générer des placeholders (À REMPLACER PAR VOS VRAIES IMAGES)
const getPlaceholder = (text: string, isOk: boolean) => 
  `https://placehold.co/600x400/${isOk ? 'dcfce7/166534' : 'fee2e2/991b1b'}?text=${encodeURIComponent(text)}`;

export const VISUAL_GUIDES: VisualGuideItem[] = [
  {
    id: 'pto_conf',
    title: 'PTO CONFORME',
    description: DESCRIPTIONS.pto_conf,
    cases: [
      { label: 'CONFORME (BYTEL)', status: 'ok', imageUrl: getPlaceholder('PTO BYTEL OK', true) },
      { label: 'NON CONFORME (Autre Opé)', status: 'ko', imageUrl: getPlaceholder('PTO ALIEN KO', false) }
    ]
  },
  {
    id: 'pbo_ref_cable',
    title: 'RÉF CABLE PBO',
    description: DESCRIPTIONS.pbo_ref_cable,
    cases: [
      { label: 'GRAVÉE / ÉTIQUETTE PRO (OK)', status: 'ok', imageUrl: getPlaceholder('REF GRAVÉE OK', true) },
      { label: 'MANUSCRITE', status: 'ko', imageUrl: getPlaceholder('MANUSCRITE', false) },
      { label: 'ILLISIBLE', status: 'ko', imageUrl: getPlaceholder('ILLISIBLE / FLOU', false) },
      { label: 'ERRONÉE', status: 'ko', imageUrl: getPlaceholder('REF ERRONÉE', false) },
      { label: 'NON GRAVÉE', status: 'ko', imageUrl: getPlaceholder('NON GRAVÉE', false) },
      { label: 'ABSENTE', status: 'ko', imageUrl: getPlaceholder('ABSENTE', false) }
    ]
  },
  {
    id: 'pto_etiquette',
    title: 'ÉTIQUETTE PTO',
    description: DESCRIPTIONS.pto_etiquette,
    cases: [
      { label: 'IMPRIMÉE & COLLÉE (OK)', status: 'ok', imageUrl: getPlaceholder('ETIQ IMPRIMÉE OK', true) },
      { label: 'MANUSCRITE', status: 'ko', imageUrl: getPlaceholder('MANUSCRITE', false) },
      { label: 'ILLISIBLE', status: 'ko', imageUrl: getPlaceholder('ILLISIBLE', false) },
      { label: 'ABSENTE', status: 'ko', imageUrl: getPlaceholder('ABSENTE', false) }
    ]
  },
  {
    id: 'pm_ref_jarretieres',
    title: 'RÉF JARRETIÈRE PM',
    description: DESCRIPTIONS.pm_ref_jarretieres,
    cases: [
      { label: 'ÉTIQUETTE VISIBLE (OK)', status: 'ok', imageUrl: getPlaceholder('ETIQ VISIBLE OK', true) },
      { label: 'MANUSCRITE', status: 'ko', imageUrl: getPlaceholder('MANUSCRITE', false) },
      { label: 'ILLISIBLE', status: 'ko', imageUrl: getPlaceholder('ILLISIBLE', false) },
      { label: 'ABSENTE', status: 'ko', imageUrl: getPlaceholder('ABSENTE', false) }
    ]
  },
  {
    id: 'pm_dechets',
    title: 'DÉCHETS PM',
    description: DESCRIPTIONS.pm_dechets,
    cases: [
      { label: 'PROPRE / PAS DE DÉCHETS (OK)', status: 'ok', imageUrl: getPlaceholder('PM PROPRE OK', true) },
      { label: 'DÉCHETS VISIBLES', status: 'ko', imageUrl: getPlaceholder('DÉCHETS AU SOL', false) }
    ]
  }
];
