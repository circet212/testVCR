export enum AppType {
  RACC = 'RACC',
  PLP = 'PLP',
  PLP_E2 = 'PLP_E2',
  PLP_E3 = 'PLP_E3'
}

export enum SourceType {
  FILE = 'FILE',
  STOCK = 'STOCK'
}

export type ToggleValue = '1' | '0' | 'NA' | 'Cor';

export interface FormData {
  [key: string]: string;
}

export interface OptionConfig {
  commDechets: string[];
  commEtiquette: string[];
  commJarretieres: string[];
  commCable: string[];
  commRefPb: string[];
  commFibre: string[];
  commPhotoPtoPlp: string[];
  suspicionOpts: string[];
  pbAvantOpts: string[];
  pbApresOpts: string[];
  voisinageOpts: string[];
  mesureExtra: string[];
}

export type ValidationStatus = 'CONF' | 'COR PND' | 'COR APR' | 'NC';