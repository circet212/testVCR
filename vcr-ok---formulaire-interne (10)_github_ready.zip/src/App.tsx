import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { AppType, FormData, ToggleValue, ValidationStatus, SourceType } from './types';
import { OPTIONS, TYPE_LABELS, DESCRIPTIONS, VISUAL_GUIDES } from './constants';
import { generateSynthesis } from './utils/generator';
import { ToggleGroup, DatalistInput } from './components/FormElements';
import { 
  GeneralIcon, PMIcon, PTOIcon, PBOIcon, AutreIcon, 
  SynthesisIcon, CopyIcon, ResetIcon, CameraIcon 
} from './components/Icons';

declare const Swal: any;
declare const XLSX: any;

type ThemeType = 'white' | 'blue' | 'green' | 'red' | 'pink' | 'purple';
type DocTab = 'actions' | 'definitions' | 'visual';

const DEPT_TO_REGION: Record<string, string> = {
  '20': 'Corse',
  '1': 'PACA', '7': 'CTA', '21': 'CTA', '38': 'CTA', '39': 'CTA', '58': 'CTA', '69': 'CTA', '71': 'CTA', '73': 'CTA', '74': 'CTA',
  '2': 'INE', '8': 'INE', '10': 'INE', '18': 'INE', '45': 'INE', '51': 'INE', '52': 'INE', '54': 'INE', '55': 'INE', '57': 'INE', '59': 'INE', '60': 'INE', '77': 'INE', '88': 'INE', '89': 'INE', '93': 'INE', '94': 'INE',
  '4': 'PACA', '5': 'PACA', '6': 'PACA', '13': 'PACA', '83': 'PACA',
  '16': 'SO', '30': 'SO', '31': 'SO', '32': 'SO', '33': 'SO', '34': 'SO', '46': 'SO', '47': 'SO', '81': 'SO', '82': 'SO', '87': 'SO'
};

const parseExcelDate = (val: any): Date | null => {
  if (!val) return null;
  if (val instanceof Date) return val;
  if (typeof val === 'number') {
    return new Date(Math.round((val - 25569) * 86400 * 1000));
  }
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d;
};

const OUI_NON_OPTS: { label: string; value: ToggleValue }[] = [
  { label: 'Oui', value: '1' },
  { label: 'Non', value: '0' }
];

interface SectionProps {
  id: string;
  title: string;
  icon: React.ReactNode;
  isVisible: boolean;
  baseColor: string;
  isActive: boolean;
  onActivate: () => void;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ id, title, icon, isVisible, baseColor, isActive, onActivate, children }) => {
  if (!isVisible) return null;
  return (
    <div 
      onClick={onActivate}
      className={`form-section transition-all duration-200 cursor-pointer bg-white ${
        isActive 
          ? `!border-2 !border-${baseColor}-500 shadow-md` 
          : `hover:!border-${baseColor}-300`
      }`}
    >
      <h3 className={`section-title flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-[0.2em] mb-1.5 py-1.5 rounded transition-all duration-200 ${
        isActive 
          ? `!bg-${baseColor}-500 !text-white !border-b-0 shadow-sm` 
          : `!text-${baseColor}-600`
      }`}>
        {icon} {title}
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-2 gap-y-0.5 px-0.5">
        {children}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [userName, setUserName] = useState<string>('');
  const [type, setType] = useState<AppType>(AppType.RACC);
  const [sourceType, setSourceType] = useState<SourceType>(SourceType.FILE);
  const [theme, setTheme] = useState<ThemeType>('white');
  const [formData, setFormData] = useState<FormData>({ status: '' });
  const [analysisInput, setAnalysisInput] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDocOpen, setIsDocOpen] = useState(false);
  const [docTab, setDocTab] = useState<DocTab>('visual');
  const [isSupervisorOpen, setIsSupervisorOpen] = useState(false);
  const [importedContactValue, setImportedContactValue] = useState<string | undefined>(undefined);
  const [importedSignature, setImportedSignature] = useState<string>('');
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [processedRows, setProcessedRows] = useState<any[]>([]);
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>(null);
  const [agentSearch, setAgentSearch] = useState('');
  const [activeSection, setActiveSection] = useState<string>('general');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const ALL_KEYS = [
    'contact', 'presta', 'Val_ROP', 'desserte',
    'pm_dechets', 'pm_comm_dechets', 'pm_cadrage', 'pm_ref_jarretieres', 'pm_mesure',
    'pto_conf', 'pto_etiquette', 'pto_suspicion', 'pto_mesure_avant', 'pto_mesure', 'pto_photo', 'pto_cadrage',
    'pbo_ref_cable', 'pbo_ref_pb', 'pbo_avant', 'pbo_apres', 'pbo_cadrage', 'pbo_mesure_e2',
    'autre_penetration', 'autre_geoloc', 'autre_voisinage', 'autre_voisin_perturbe', 'autre_sauvage', 'autre_nacelle', 'autre_photo_poteau'
  ];

  const LABEL_TO_KEY_MAP: Record<string, string> = {
    'CONTACT': 'contact', 'CHGT PRESTA': 'presta', 'VALIDATION ROP': 'Val_ROP', 'CHGT DESSERTE': 'desserte',
    'DÉCHETS PM': 'pm_dechets', 'CADRAGE PM': 'pm_cadrage', 'RÉF JARR.': 'pm_ref_jarretieres', 'MESURE PM': 'pm_mesure',
    'PTO CONFORME': 'pto_conf', 'ÉTIQUETTE PTO': 'pto_etiquette', 'SUSPICION FRAUDE': 'pto_suspicion', 
    'MESURE PTO AVANT': 'pto_mesure_avant', 'MESURE PTO': 'pto_mesure',
    'PHOTO PTO': 'pto_photo', 'CADRAGE PTO': 'pto_cadrage', 'RÉF CABLE': 'pbo_ref_cable', 'RÉF PB': 'pbo_ref_pb',
    'PHOTO PBO AVANT': 'pbo_avant', 'PHOTO PBO APRÈS': 'pbo_apres', 'CADRAGE PB': 'pbo_cadrage', 'MESURE E2': 'pbo_mesure_e2',
    'PÉNÉTRATION': 'autre_penetration', 'GÉOLOCALISATION': 'autre_geoloc', 'CHECKVOISINAGE': 'autre_voisinage',
    'VOISIN PERTURBÉ': 'autre_voisin_perturbe', 'INC': 'autre_sauvage', 'NACELLE': 'autre_nacelle', 'POTEAU': 'autre_photo_poteau'
  };

  const COMMENT_FIELDS_MAP: Record<string, string> = {
    'pm_dechets': 'pm_comm_dechets', 'pm_ref_jarretieres': 'pm_comm_jarretieres', 'pm_mesure': 'pm_mesure_extra',
    'pto_etiquette': 'pto_comm_etiquette', 'pto_suspicion': 'pto_comm_suspicion', 'pto_mesure': 'pto_mesure_extra',
    'pto_photo': 'pto_comm_photo', 'pbo_ref_cable': 'pbo_comm_cable', 'pbo_ref_pb': 'pbo_comm_pb',
    'pbo_avant': 'pbo_comm_avant', 'pbo_apres': 'pbo_comm_apres', 'autre_voisinage': 'autre_comm_voisinage'
  };

  const isFieldVisible = useCallback((id: string, currentType: AppType): boolean => {
    if (id === 'pto_mesure_avant') return currentType === AppType.PLP_E2;
    if (id === 'pbo_mesure_e2') return currentType === AppType.PLP_E2;
    if (['pto_photo', 'pto_comm_photo'].includes(id)) return currentType === AppType.PLP;
    if (currentType === AppType.RACC || currentType === AppType.PLP_E2) return true;
    if (currentType === AppType.PLP) {
      if (['pto_etiquette', 'pto_mesure'].includes(id)) return true;
      if (['pm_dechets', 'pm_comm_dechets', 'pm_mesure'].includes(id)) return true;
      if (['autre_voisinage'].includes(id)) return true; 
      return false;
    }
    if (currentType === AppType.PLP_E3) {
      const hiddenInE3 = ['pbo_ref_cable', 'pbo_ref_pb', 'pbo_avant', 'pbo_apres', 'pbo_cadrage', 'pbo_mesure_e2', 'autre_nacelle', 'autre_photo_poteau'];
      return !hiddenInE3.includes(id);
    }
    return true;
  }, []);

  const isBlockVisible = useCallback((ids: string[]): boolean => ids.some(id => isFieldVisible(id, type)), [isFieldVisible, type]);

  const getDefaultFormData = useCallback((currentType: AppType, currentSource: SourceType): FormData => {
    const data: FormData = { status: '' };
    ALL_KEYS.forEach(key => {
      if (isFieldVisible(key, currentType)) {
        if (key === 'pm_comm_dechets') data[key] = '';
        else if (key === 'contact') data[key] = currentSource === SourceType.FILE ? '1' : '0';
        else if (key === 'pto_mesure_avant' && currentType === AppType.PLP_E2) data[key] = '1';
        else if (key === 'pbo_mesure_e2' && currentType === AppType.PLP_E2) data[key] = '1';
        else if (['pbo_mesure_e2', 'autre_nacelle', 'autre_photo_poteau'].includes(key)) data[key] = 'NA';
        else if (['presta', 'Val_ROP', 'desserte', 'autre_voisin_perturbe', 'autre_sauvage'].includes(key)) data[key] = '0';
        else data[key] = '1';
      } else { data[key] = 'NA'; }
    });
    return data;
  }, [isFieldVisible]);

  const calculateStatus = useCallback((data: FormData, currentType: AppType, hasImportedContact: boolean): ValidationStatus | '' => {
    const informativeFields = ['contact', 'presta', 'Val_ROP', 'desserte'];
    const techFields = ALL_KEYS.filter(k => 
      isFieldVisible(k, currentType) && 
      !k.includes('_comm_') && 
      !k.includes('_extra') && 
      !informativeFields.includes(k)
    );
    
    let hasKO = false; 
    let hasCor = false;
    
    for (const key of techFields) {
      const val = data[key];
      if (val === 'Cor') hasCor = true;
      else if (['autre_voisin_perturbe', 'autre_sauvage'].includes(key)) { if (val === '1') hasKO = true; }
      else { if (val === '0') hasKO = true; }
    }
    
    if (hasKO) return 'NC';
    if (hasCor) {
      return hasImportedContact ? 'COR APR' : 'COR PND';
    }
    return 'CONF';
  }, [isFieldVisible]);

  const updateField = useCallback((id: string, value: string) => {
    setFormData(prev => {
      const newData = { ...prev, [id]: value };
      if (id !== 'status') {
        const newStatus = calculateStatus(newData, type, importedContactValue !== undefined);
        if (newStatus) newData.status = newStatus;
      }
      return newData;
    });
  }, [calculateStatus, type, importedContactValue]);

  const handleDossierVide = () => {
    const newData = { ...formData };
    ALL_KEYS.forEach(key => {
      if (!isFieldVisible(key, type)) return;
      if (key === 'contact') return;
      if (key.includes('_comm_') || key.includes('_extra')) return;

      if (['autre_voisin_perturbe', 'autre_sauvage'].includes(key)) newData[key] = '1';
      else if (['presta', 'Val_ROP', 'desserte'].includes(key)) newData[key] = '0';
      else if (key !== 'status') newData[key] = '0';

      const commentField = COMMENT_FIELDS_MAP[key];
      if (commentField) newData[commentField] = (key === 'pm_dechets') ? 'Dossier vide' : '.';
      if (key === 'pm_mesure') newData['pm_mesure_extra'] = '.';
      if (key === 'pto_mesure') newData['pto_mesure_extra'] = '.';
      if (key === 'pm_ref_jarretieres') newData['pm_comm_jarretieres'] = '.';
      if (key === 'pto_etiquette') newData['pto_comm_etiquette'] = '.';
      if (key === 'pto_suspicion') newData['pto_comm_suspicion'] = '.';
    });
    newData['pm_comm_dechets'] = 'Dossier vide';
    newData['pm_dechets'] = '0';
    newData.status = calculateStatus(newData, type, importedContactValue !== undefined);
    setFormData(newData);
    Swal.fire({ icon: 'warning', title: 'Dossier Vide Appliqué', text: 'Tous les éléments ont été mis en Non-Conforme.', timer: 1500, showConfirmButton: false, toast: true, position: 'top-end' });
  };

  useEffect(() => { document.body.className = `theme-${theme}`; }, [theme]);

  // Handle User Name Prompt on Mount
  useEffect(() => {
    const storedUser = sessionStorage.getItem('vcr_username');
    if (storedUser) {
        setUserName(storedUser);
    } else {
        Swal.fire({
            title: 'Bienvenue',
            text: 'Veuillez saisir votre Prénom et NOM',
            input: 'text',
            inputPlaceholder: 'Ex: Jacques DUPONT',
            allowOutsideClick: false,
            allowEscapeKey: false,
            confirmButtonText: 'Valider',
            confirmButtonColor: '#1e293b',
            backdrop: `rgba(0,0,0,0.8)`,
            inputValidator: (value: string) => {
                if (!value) return 'La saisie est obligatoire pour continuer.';
            }
        }).then((result: any) => {
            if (result.isConfirmed) {
                sessionStorage.setItem('vcr_username', result.value);
                setUserName(result.value);
            }
        });
    }
  }, []);

  // Handle Dashboard Shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check for Ctrl + Shift + D (case insensitive safe check using code or key variants)
      if (e.ctrlKey && e.shiftKey && (e.key === 'D' || e.key === 'd' || e.code === 'KeyD')) {
        e.preventDefault();
        setIsSupervisorOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (!formData.status) setFormData(getDefaultFormData(type, sourceType));
  }, [type, sourceType, getDefaultFormData, formData.status]);

  // Force update contact when sourceType changes, even if form is initialized
  useEffect(() => {
    setFormData(prev => ({
        ...prev,
        contact: sourceType === SourceType.FILE ? '1' : '0'
    }));
  }, [sourceType]);

  useEffect(() => {
    if (isModalOpen && textareaRef.current) {
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    }
  }, [isModalOpen]);

  useEffect(() => {
    const newStatus = calculateStatus(formData, type, importedContactValue !== undefined);
    if (newStatus && newStatus !== formData.status) {
      setFormData(prev => ({ ...prev, status: newStatus }));
    }
  }, [importedContactValue, type, calculateStatus]);

  const checkSynthesisCompliance = (raw: string): boolean => {
    if (!raw || !raw.includes('[[') || !raw.includes(']]')) return false;
    const match = raw.match(/\[\[(.*?)\]\]/s);
    if (!match) return false;
    const content = match[1];
    const partsCount = content.split('\\\\').length;
    return partsCount >= 28;
  };

  const handleReset = async () => {
    const result = await Swal.fire({
      title: 'Réinitialiser le formulaire ?',
      text: "Toutes les données saisies ainsi que le 2ème contact seront effacés.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ef4444',
      cancelButtonColor: '#64748b',
      confirmButtonText: 'Oui, effacer',
      cancelButtonText: 'Annuler'
    });
    if (result.isConfirmed) {
      setFormData(getDefaultFormData(type, sourceType));
      setImportedContactValue(undefined);
      setImportedSignature('');
      Swal.fire({ title: 'Effacé !', icon: 'success', timer: 800, showConfirmButton: false, toast: true, position: 'top-end' });
    }
  };

  const handleAnalysis = (text: string) => {
    setAnalysisInput(text);
    if (!text || !text.includes('[[')) return;
    
    // Extraction de la signature (Ancien format "Par :" ou Nouveau format "C1 (...) :")
    let extractedSig = '';
    const oldSigMatch = text.match(/Par\s*:\s*([^\n\r]+)/i);
    if (oldSigMatch) {
      extractedSig = oldSigMatch[1].trim();
    } else {
      // Tentative de récupération d'un format "C1 (Nom) :" déjà existant
      const newSigMatch = text.match(/C1\s*\(([^)]+)\)\s*:/i);
      if (newSigMatch) extractedSig = newSigMatch[1].trim();
    }
    setImportedSignature(extractedSig);

    const regex = /\[\[(.*?)\]\]/s;
    const match = text.match(regex);
    if (!match) return;
    const content = match[1];
    const parts = content.split('\\\\');
    const newFormData: FormData = { ...formData };
    let detectedType = type;
    let importedContact = undefined;
    parts.forEach(part => {
      const [label, valuePart] = part.split(' : ').map(s => s?.trim());
      if (!label || !valuePart) return;
      if (label === 'TYPE') {
        if (valuePart === 'RACC') detectedType = AppType.RACC;
        else if (valuePart === 'PLP') detectedType = AppType.PLP;
        else if (valuePart === 'E2') detectedType = AppType.PLP_E2;
        else if (valuePart === 'E3') detectedType = AppType.PLP_E3;
        setType(detectedType);
        return;
      }
      if (label === 'STATUT VALIDATION') {
        let s = valuePart;
        if (s === 'NC OK') s = 'CONF';
        else if (s === 'NC COR') s = 'COR PND';
        else if (s === 'NC KO') s = 'NC';
        newFormData.status = s as ValidationStatus;
        return;
      }
      const key = LABEL_TO_KEY_MAP[label];
      if (!key) return;
      let cleanValue = valuePart;
      let comment = '';
      if (valuePart.includes('(')) {
        const valMatch = valuePart.match(/^(.*?)\s*\((.*?)\)$/);
        if (valMatch) { cleanValue = valMatch[1].trim(); comment = valMatch[2].trim(); }
      }
      if (key === 'contact') { importedContact = cleanValue === 'Avec' ? '1' : (cleanValue === 'Sans' ? '0' : cleanValue); return; }
      let finalVal = cleanValue;
      if (['presta', 'Val_ROP', 'desserte', 'autre_voisin_perturbe', 'autre_sauvage'].includes(key)) {
        if (cleanValue === 'Cor') finalVal = 'Cor';
        else finalVal = cleanValue === 'NA' ? 'NA' : (cleanValue === 'Oui' ? '1' : '0');
      } else {
        if (cleanValue === 'Cor') finalVal = 'Cor';
        else if (cleanValue === '1') finalVal = '1';
        else if (cleanValue === '0') finalVal = '0';
        else if (cleanValue === 'NA') finalVal = 'NA';
      }
      newFormData[key] = finalVal;
      if (COMMENT_FIELDS_MAP[key]) newFormData[COMMENT_FIELDS_MAP[key]] = comment;
    });
    setImportedContactValue(importedContact);
    setFormData(newFormData);
    setIsModalOpen(false);
    setAnalysisInput('');
    Swal.fire({ icon: 'success', title: 'Import Réussi', timer: 1200, showConfirmButton: false, toast: true, position: 'top-end' });
  };

  const handleDownloadImage = async (elementId: string, title: string) => {
    const element = document.getElementById(elementId);
    if (!element) return;
    try {
      const canvas = await (window as any).html2canvas(element, { scale: 2, useCORS: true, backgroundColor: '#ffffff' });
      const link = document.createElement('a');
      link.download = `${title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (e) {
      Swal.fire('Erreur', 'Impossible de générer l\'image.', 'error');
    }
  };

  const handleSupervisorFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary', cellDates: true });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);
        if (data.length === 0) { Swal.fire('Erreur', 'Le fichier est vide.', 'error'); return; }

        const stats: any = {
          total: 0, ok: 0, ko: 0, cor: 0, invalidSynthesis: 0,
          koItems: {}, corItems: {},
          departments: {}, regions: {}, agents: {},
          technicians: {}, 
          matrix: {}, 
          dateRange: { min: null, max: null }
        };
        const enrichedRows: any[] = [];

        data.forEach((row: any) => {
          const synthesisRaw = row['Commentaire 2'] || row['u_commentaire_2'] || '';
          const deptRaw = String(row['Département'] || row['u_department'] || 'Inconnu').trim().replace(/^0+/, '');
          const agentRaw = String(row['Fermé par'] || row['closed_by'] || row['Closed by'] || 'Anonyme').trim();
          const techRaw = String(row['Technicien'] || row['Technicien	'] || row['u_technicien'] || 'Non Renseigné').trim();

          const isCompliant = checkSynthesisCompliance(synthesisRaw);
          const hasSynthesis = synthesisRaw && synthesisRaw.includes('[[');

          const region = DEPT_TO_REGION[deptRaw] || 'Inconnue';

          if (!stats.agents[agentRaw]) stats.agents[agentRaw] = { 
              name: agentRaw, total: 0, ok: 0, ko: 0, cor: 0, avecContact: 0, sansContact: 0, compliant: 0, 
              typeCounts: { RACC: 0, PLP: 0, E2: 0, E3: 0 },
              koMotifs: {}, corMotifs: {} 
          };
          
          if (!stats.technicians[techRaw]) {
             stats.technicians[techRaw] = { 
                name: techRaw, ko: 0, cor: 0, 
                koMotifs: {}, corMotifs: {},
                region: region,
                department: deptRaw
             };
          } else {
             if (region !== 'Inconnue') stats.technicians[techRaw].region = region;
             if (deptRaw !== 'Inconnu') stats.technicians[techRaw].department = deptRaw;
          }

          stats.agents[agentRaw].total++;
          stats.total++; 

          if (isCompliant) stats.agents[agentRaw].compliant++;

          if (!hasSynthesis || !isCompliant) {
             stats.invalidSynthesis++;
             enrichedRows.push({ ...row, _agent: agentRaw, _isSynthesisCompliant: false, _status_audit: 'SYNTHÈSE INVALIDE' });
             return;
          }

          const rowEnrichment: any = { ...row, _region: region, _agent: agentRaw, _isSynthesisCompliant: isCompliant };

          const regex = /\[\[(.*?)\]\]/s;
          const match = synthesisRaw.match(regex);
          if (match) {
            const parts = match[1].split('\\\\');
            let statusRaw: ValidationStatus = 'CONF';
            let contactVal = 'Sans';
            let typeImported = 'RACC';

            for (const part of parts) {
              const labelParts = part.split(' : ');
              if (labelParts.length < 2) continue;
              const label = labelParts[0].trim();
              const valPart = labelParts[1].trim();
              if (label === 'STATUT VALIDATION') {
                const s = valPart;
                if (s === 'NC OK') statusRaw = 'CONF';
                else if (s === 'NC COR') statusRaw = 'COR PND';
                else if (s === 'NC KO') statusRaw = 'NC';
                else statusRaw = s as ValidationStatus;
              }
              if (label === 'CONTACT') contactVal = valPart;
              if (label === 'TYPE') typeImported = valPart;
              
              const cleanValOnly = valPart.split(' (')[0].trim();
              rowEnrichment[`ITEM_${label}`] = valPart;
              
              if (label !== 'TYPE' && label !== 'STATUT VALIDATION' && label !== 'CONTACT') {
                if (cleanValOnly === '0') {
                    stats.koItems[label] = (stats.koItems[label] || 0) + 1;
                    const motif = `${label}${valPart.includes('(') ? ' ' + valPart.match(/\((.*?)\)$/)?.[0] : ''}`;
                    stats.agents[agentRaw].koMotifs[motif] = (stats.agents[agentRaw].koMotifs[motif] || 0) + 1;
                    stats.technicians[techRaw].koMotifs[motif] = (stats.technicians[techRaw].koMotifs[motif] || 0) + 1;
                }
                else if (cleanValOnly === 'Cor') {
                    stats.corItems[label] = (stats.corItems[label] || 0) + 1;
                    const motif = `${label}${valPart.includes('(') ? ' ' + valPart.match(/\((.*?)\)$/)?.[0] : ''}`;
                    stats.agents[agentRaw].corMotifs[motif] = (stats.agents[agentRaw].corMotifs[motif] || 0) + 1;
                    stats.technicians[techRaw].corMotifs[motif] = (stats.technicians[techRaw].corMotifs[motif] || 0) + 1;
                }
              }
            }

            if (stats.agents[agentRaw].typeCounts[typeImported] !== undefined) stats.agents[agentRaw].typeCounts[typeImported]++;

            if (!stats.matrix[region]) stats.matrix[region] = {};
            if (!stats.matrix[region][typeImported]) stats.matrix[region][typeImported] = { CONF: 0, 'COR PND': 0, 'COR APR': 0, NC: 0, total: 0 };
            stats.matrix[region][typeImported][statusRaw]++;
            stats.matrix[region][typeImported].total++;

            const isOK = statusRaw === 'CONF';
            const isKO = statusRaw === 'NC';
            const isCOR = statusRaw.startsWith('COR');

            if (isOK) { 
                stats.ok++; 
                stats.agents[agentRaw].ok++; 
            } else if (isKO) { 
                stats.ko++; 
                stats.agents[agentRaw].ko++; 
                stats.technicians[techRaw].ko++; 
            } else if (isCOR) { 
                stats.cor++; 
                stats.agents[agentRaw].cor++; 
                stats.technicians[techRaw].cor++; 
            }

            if (contactVal === 'Avec') stats.agents[agentRaw].avecContact++;
            else stats.agents[agentRaw].sansContact++;

            if (!stats.departments[deptRaw]) stats.departments[deptRaw] = { total: 0, ok: 0, ko: 0, cor: 0, region, koMotifs: {}, corMotifs: {} };
            stats.departments[deptRaw].total++;
            if (isOK) stats.departments[deptRaw].ok++;
            else if (isKO) {
              stats.departments[deptRaw].ko++;
              parts.forEach(p => {
                const [l, v] = p.split(' : ');
                if (v?.startsWith('0')) {
                  const m = v.match(/\((.*?)\)$/)?.[1] || 'NC';
                  stats.departments[deptRaw].koMotifs[`${l}: ${m}`] = (stats.departments[deptRaw].koMotifs[`${l}: ${m}`] || 0) + 1;
                }
              });
            } else if (isCOR) {
              stats.departments[deptRaw].cor++;
              parts.forEach(p => {
                const [l, v] = p.split(' : ');
                if (v?.startsWith('Cor')) {
                  const m = v.match(/\((.*?)\)$/)?.[1] || 'NC';
                  stats.departments[deptRaw].corMotifs[`${l}: ${m}`] = (stats.departments[deptRaw].corMotifs[`${l}: ${m}`] || 0) + 1;
                }
              });
            }

            if (!stats.regions[region]) stats.regions[region] = { total: 0, ok: 0, ko: 0, cor: 0, koMotifs: {}, corMotifs: {} };
            stats.regions[region].total++;
            if (isOK) stats.regions[region].ok++;
            else if (isKO) {
              stats.regions[region].ko++;
              parts.forEach(p => {
                const [l, v] = p.split(' : ');
                if (v?.startsWith('0')) {
                   const m = v.match(/\((.*?)\)$/)?.[1] || 'NC';
                   stats.regions[region].koMotifs[`${l}: ${m}`] = (stats.regions[region].koMotifs[`${l}: ${m}`] || 0) + 1;
                }
             });
            } else if (isCOR) {
              stats.regions[region].cor++;
              parts.forEach(p => {
                const [l, v] = p.split(' : ');
                if (v?.startsWith('Cor')) {
                   const m = v.match(/\((.*?)\)$/)?.[1] || 'NC';
                   stats.regions[region].corMotifs[`${l}: ${m}`] = (stats.regions[region].corMotifs[`${l}: ${m}`] || 0) + 1;
                }
             });
            }
            enrichedRows.push(rowEnrichment);
          }
        });
        setProcessedRows(enrichedRows);
        setDashboardData(stats);
      } catch (err) { Swal.fire('Erreur', 'Échec de la lecture.', 'error'); }
    };
    reader.readAsBinaryString(file);
  };

  const handleExportDashboard = () => {
    if (processedRows.length === 0) return;
    const ws = XLSX.utils.json_to_sheet(processedRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Audit VCR");
    XLSX.writeFile(wb, `Audit_VCR_Complet_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleExportAgents = () => {
    if (!filteredAgents.length) return;
    const exportData = filteredAgents.map((a: any) => ({
        Agent: a.name,
        Total: a.total,
        OK: a.ok,
        KO: a.ko,
        COR: a.cor,
        RACC: a.typeCounts.RACC,
        PLP: a.typeCounts.PLP,
        E2: a.typeCounts.E2,
        E3: a.typeCounts.E3,
        Conformité: ((a.compliant/a.total)*100).toFixed(1) + '%'
    }));
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Performance Agents");
    XLSX.writeFile(wb, `Audit_Agents_VCR_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const filteredAgents = useMemo(() => {
    if (!dashboardData) return [];
    let agents = Object.values(dashboardData.agents);
    if (agentSearch) agents = agents.filter((a: any) => a.name.toLowerCase().includes(agentSearch.toLowerCase()));
    if (sortConfig) {
      agents.sort((a: any, b: any) => {
        let valA = a[sortConfig.key];
        let valB = b[sortConfig.key];
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return agents;
  }, [dashboardData, agentSearch, sortConfig]);

  const topKOTechs = useMemo(() => {
    if (!dashboardData) return [];
    return Object.values(dashboardData.technicians)
        .sort((a: any, b: any) => b.ko - a.ko)
        .slice(0, 5)
        .filter((a: any) => a.ko > 0);
  }, [dashboardData]);

  const topCORTechs = useMemo(() => {
    if (!dashboardData) return [];
    return Object.values(dashboardData.technicians)
        .sort((a: any, b: any) => b.cor - a.cor)
        .slice(0, 5)
        .filter((a: any) => a.cor > 0);
  }, [dashboardData]);

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    setSortConfig({ key, direction });
  };

  const synthesisText = useMemo(() => {
    let allFilled = true;
    if (!formData.status) allFilled = false;
    ALL_KEYS.forEach(id => {
      if (isFieldVisible(id, type)) {
        const val = formData[id];
        if (id === 'pm_comm_dechets') { if (val === undefined || val.trim() === '') allFilled = false; return; }
        if (id.includes('_comm_') || id.includes('_extra')) return;
        if (val === undefined || val === '') allFilled = false;
        if (val === '0' || val === 'Cor') {
          const commId = COMMENT_FIELDS_MAP[id];
          if (commId && (!formData[commId] || formData[commId].trim() === '')) allFilled = false;
        }
      }
    });
    if (!allFilled) return "--- CHAMPS OBLIGATOIRES (*) MANQUANTS ---";
    return generateSynthesis(type, formData, importedContactValue, userName, importedSignature);
  }, [type, formData, isFieldVisible, importedContactValue, userName, importedSignature]);

  const isFormComplete = !synthesisText.includes("MANQUANTS");

  return (
    <div className="flex flex-col h-full w-full overflow-hidden">
      {/* NAVIGATION BAR */}
      <nav className="flex w-full shrink-0 items-center justify-between px-5 py-2 z-30 shadow-md">
        <div className="flex gap-1.5 p-1 bg-black/20 rounded-lg overflow-x-auto custom-scroll">
          {Object.values(AppType).map((t) => (
            <button key={t} onClick={() => setType(t)} className={`w-32 py-2 text-[10px] font-black uppercase tracking-widest transition-all rounded-md flex items-center justify-center shrink-0 ${type === t ? 'bg-white/20 text-white shadow border-b-2 border-white/50' : 'text-slate-300 hover:text-white'}`}>{TYPE_LABELS[t]}</button>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsDocOpen(true)} className="p-2 text-white/60 hover:text-white transition-colors" title="Documentation">
             <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </button>
          <button onClick={handleDossierVide} className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-full border border-white/20 shadow-lg transition-all active:scale-95">
             <span className="text-[10px] font-black uppercase tracking-widest">DOSSIER VIDE</span>
          </button>
          <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-slate-800/80 hover:bg-slate-900 text-white rounded-full border border-white/20 shadow-lg transition-all active:scale-95 group"><SynthesisIcon /><span className="text-[10px] font-black uppercase tracking-widest">2ème CONTACT</span></button>
          <div className={`flex items-center gap-2 px-3 py-1 rounded-full border transition-all bg-black/20 ${isFormComplete ? 'border-emerald-500/40' : 'border-amber-500/40'}`}><div className={`w-1.5 h-1.5 rounded-full ${isFormComplete ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'}`} /><span className={`text-[9px] font-black uppercase tracking-widest ${isFormComplete ? 'text-emerald-400' : 'text-amber-400'}`}>{isFormComplete ? "COMPLET" : "INCOMPLET"}</span></div>
          <div className="flex bg-black/40 p-0.5 rounded-full border border-white/5">
            <button onClick={() => setSourceType(SourceType.FILE)} className={`px-3 py-1 text-[8px] font-black uppercase rounded-full transition-all ${sourceType === SourceType.FILE ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}>FILE</button>
            <button onClick={() => setSourceType(SourceType.STOCK)} className={`px-3 py-1 text-[8px] font-black uppercase rounded-full transition-all ${sourceType === SourceType.STOCK ? 'bg-orange-500 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}>STOCK</button>
          </div>
        </div>
      </nav>

      {/* DOCUMENTATION MODAL */}
      {isDocOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl h-[85vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-300">
            <div className="bg-slate-900 px-8 py-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-4">
                    <div className="p-2.5 bg-blue-500/20 text-blue-400 rounded-xl"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg></div>
                    <div><h2 className="text-white font-black text-lg uppercase tracking-widest leading-none">Guide d'utilisation</h2><p className="text-slate-400 text-[10px] font-bold uppercase mt-1 tracking-widest">AIDE AU TRAITEMENT VCR OK</p></div>
                </div>
                <div className="h-8 w-px bg-slate-700 mx-2"></div>
                <div className="flex gap-2">
                    <button onClick={() => setDocTab('visual')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${docTab === 'visual' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}>Guide Visuel</button>
                    <button onClick={() => setDocTab('actions')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${docTab === 'actions' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}>Actions</button>
                    <button onClick={() => setDocTab('definitions')} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${docTab === 'definitions' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}>Définitions</button>
                </div>
              </div>
              <button onClick={() => setIsDocOpen(false)} className="p-2 text-slate-400 hover:text-white transition-colors"><svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"/></svg></button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-10 custom-scroll bg-slate-50">
              {docTab === 'visual' && (
                  <div className="space-y-12">
                      <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl mb-8 flex items-start gap-3">
                          <div className="p-2 bg-blue-100 rounded-lg text-blue-600"><CameraIcon /></div>
                          <div>
                              <h4 className="text-blue-800 font-bold text-sm uppercase">Note sur les images</h4>
                              <p className="text-blue-600 text-xs mt-1">Les images ci-dessous sont des exemples. Pour une expérience optimale, veuillez remplacer les URLs de placeholder dans le code par vos propres photos de référence techniques.</p>
                          </div>
                      </div>
                      {VISUAL_GUIDES.map((guide) => (
                          <div key={guide.id} className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                              <div className="mb-6 border-b border-slate-100 pb-4">
                                  <h3 className="text-slate-900 font-black text-xl uppercase tracking-widest mb-2 flex items-center gap-3">
                                      <span className="w-2 h-8 bg-blue-600 rounded-full"></span>
                                      {guide.title}
                                  </h3>
                                  <p className="text-slate-500 font-medium text-sm ml-5">{guide.description}</p>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                  {guide.cases.map((c, idx) => (
                                      <div key={idx} className={`group relative rounded-2xl overflow-hidden border-2 transition-all hover:shadow-xl ${c.status === 'ok' ? 'border-emerald-100 bg-emerald-50/30' : 'border-red-100 bg-red-50/30'}`}>
                                          <div className="aspect-[4/3] w-full overflow-hidden bg-slate-200 relative">
                                              <img src={c.imageUrl} alt={c.label} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                                              <div className={`absolute top-3 right-3 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg ${c.status === 'ok' ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
                                                  {c.status === 'ok' ? 'CONFORME' : 'NON CONFORME'}
                                              </div>
                                          </div>
                                          <div className="p-4">
                                              <div className={`text-xs font-black uppercase tracking-wider ${c.status === 'ok' ? 'text-emerald-700' : 'text-red-700'}`}>
                                                  {c.label}
                                              </div>
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </div>
                      ))}
                  </div>
              )}

              {docTab === 'actions' && (
                <div>
                    <h3 className="text-blue-600 font-black text-xs uppercase tracking-[0.2em] mb-6 flex items-center gap-2 border-b-2 border-blue-50 pb-2"><SynthesisIcon /> GUIDE DES ACTIONS (BOUTONS)</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-slate-800 mb-2 uppercase">TYPOLOGIES (RACC/PLP...)</div><p className="text-xs text-slate-500 leading-relaxed font-medium">Permet d'adapter dynamiquement les champs requis et l'affichage selon le type d'intervention sélectionné. À choisir impérativement avant la saisie.</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-red-600 mb-2 uppercase">DOSSIER VIDE</div><p className="text-xs text-slate-500 leading-relaxed font-medium">Automatise le remplissage de tous les éléments en Non-Conforme (0). Idéal pour les dossiers sans aucune photo ou données exploitables.</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-indigo-600 mb-2 uppercase">2ème CONTACT</div><p className="text-xs text-slate-500 leading-relaxed font-medium">Outil d'import intelligent. Collez une synthèse déjà générée (format [[...]]) pour pré-remplir instantanément tout le formulaire.</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-slate-800 mb-2 uppercase">MODES FILE / STOCK</div><p className="text-xs text-slate-500 leading-relaxed font-medium">FILE définit le contact par défaut sur "Avec" (appels entrants). STOCK le définit sur "Sans" (traitements asynchrones).</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-emerald-600 mb-2 uppercase">BOUTON COPIER</div><p className="text-xs text-slate-500 leading-relaxed font-medium">Vérifie que tous les champs obligatoires sont remplis et copie le CR formaté complet dans votre presse-papier.</p></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"><div className="text-[11px] font-black text-red-500 mb-2 uppercase">RÉINITIALISER (FLÈCHE)</div><p className="text-xs text-slate-500 leading-relaxed font-medium">Efface l'intégralité du formulaire en cours pour démarrer un nouveau traitement de dossier à zéro.</p></div>
                    </div>
                </div>
              )}

              {docTab === 'definitions' && (
                <div>
                    <h3 className="text-blue-600 font-black text-xs uppercase tracking-[0.2em] mb-6 flex items-center gap-2 border-b-2 border-blue-50 pb-2"><GeneralIcon /> DÉFINITIONS DES CHAMPS</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(DESCRIPTIONS).map(([key, desc]) => (
                        <div key={key} className="flex gap-4 p-5 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all">
                        <div className="shrink-0 w-2 h-2 rounded-full bg-blue-400 mt-1.5"></div>
                        <div>
                            <div className="text-[10px] font-black text-slate-800 uppercase mb-1">{LABEL_TO_KEY_MAP[key.toUpperCase()] || key.replace(/_/g, ' ').toUpperCase()}</div>
                            <p className="text-xs text-slate-500 font-medium leading-relaxed">{desc}</p>
                        </div>
                        </div>
                    ))}
                    </div>
                </div>
              )}
            </div>
            
            <div className="bg-slate-100 px-8 py-5 flex justify-end border-t border-slate-200 shrink-0">
              <button onClick={() => setIsDocOpen(false)} className="px-8 py-2.5 bg-slate-900 text-white text-[10px] font-black uppercase rounded-xl shadow-lg hover:bg-black transition-all">Fermer</button>
            </div>
          </div>
        </div>
      )}

      {/* SUPERVISOR DASHBOARD */}
      {isSupervisorOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-100/80 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-slate-50 border border-slate-300 rounded-3xl shadow-2xl w-[98vw] h-[95vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-300">
            <div className="bg-white px-8 py-5 flex items-center justify-between border-b border-slate-200">
              <div className="flex items-center gap-4">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl border border-indigo-100"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg></div>
                <div><h2 className="text-slate-900 font-black text-lg uppercase tracking-widest">Supervisor Intelligence</h2><p className="text-slate-500 text-[10px] font-medium tracking-wider">ANALYSE DE PERFORMANCE & AUDIT QUALITÉ V4.0</p></div>
              </div>
              <div className="flex items-center gap-3">
                {dashboardData && <button onClick={handleExportDashboard} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-sm transition-all">EXPORT GLOBAL AUDIT</button>}
                <label className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer shadow-sm transition-all">IMPORTER UN FICHIER<input type="file" className="hidden" accept=".xlsx, .xls, .csv" onChange={handleSupervisorFileUpload} /></label>
                <button onClick={() => setIsSupervisorOpen(false)} className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"><svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"/></svg></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-8 custom-scroll space-y-12 bg-slate-50/50">
              {dashboardData ? (
                <>
                  <div className="grid grid-cols-5 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col"><span className="text-slate-500 text-[9px] font-black uppercase mb-1">Total Dossiers (CRM)</span><span className="text-slate-900 text-3xl font-black">{dashboardData.total}</span></div>
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col border-l-4 border-l-slate-400 bg-slate-50"><span className="text-slate-500 text-[9px] font-black uppercase mb-1">Synthèse Invalide / Absente</span><span className="text-slate-600 text-3xl font-black">{dashboardData.invalidSynthesis} <span className="text-sm opacity-60">({((dashboardData.invalidSynthesis/dashboardData.total)*100).toFixed(1)}%)</span></span></div>
                    <div className="bg-white p-6 rounded-2xl border border-emerald-100 shadow-sm flex flex-col border-l-4 border-l-emerald-500"><span className="text-emerald-600 text-[9px] font-black uppercase mb-1">Taux Qualité (OK)</span><span className="text-emerald-600 text-3xl font-black">{dashboardData.ok} <span className="text-sm opacity-60">({((dashboardData.ok/dashboardData.total)*100).toFixed(1)}%)</span></span></div>
                    <div className="bg-white p-6 rounded-2xl border border-red-100 shadow-sm flex flex-col border-l-4 border-l-red-500"><span className="text-red-600 text-[9px] font-black uppercase mb-1">Non-Conformités (KO)</span><span className="text-red-600 text-3xl font-black">{dashboardData.ko} <span className="text-sm opacity-60">({((dashboardData.ko/dashboardData.total)*100).toFixed(1)}%)</span></span></div>
                    <div className="bg-white p-6 rounded-2xl border border-amber-100 shadow-sm flex flex-col border-l-4 border-l-amber-500"><span className="text-amber-600 text-[9px] font-black uppercase mb-1">Corrections Appliquées</span><span className="text-amber-600 text-3xl font-black">{dashboardData.cor} <span className="text-sm opacity-60">({((dashboardData.cor/dashboardData.total)*100).toFixed(1)}%)</span></span></div>
                  </div>

                  {/* TOP 5 SECTION */}
                  <div className="grid grid-cols-2 gap-8">
                     {/* TOP KO AGENTS */}
                     <div id="block-top5-ko" className="bg-white rounded-3xl border border-red-100 p-8 shadow-sm">
                        <h3 className="text-red-600 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                            <span className="flex items-center gap-2"><span className="bg-red-100 p-1 rounded">🏆</span> TOP 5 TECHNICIENS - NON-CONFORMITÉ (KO)</span>
                            <button onClick={() => handleDownloadImage('block-top5-ko', 'Top5_Tech_KO')} className="text-red-300 hover:text-red-600 transition-colors"><CameraIcon /></button>
                        </h3>
                        <div className="space-y-4">
                            {topKOTechs.map((tech: any, i: number) => (
                                <div key={i} className="bg-red-50/50 rounded-xl p-4 border border-red-100">
                                    <div className="flex justify-between items-center mb-2">
                                        <div className="flex items-center gap-3">
                                            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-red-600 text-white text-[10px] font-black shrink-0">{i + 1}</span>
                                            <div className="flex flex-col">
                                                <span className="text-slate-900 font-bold text-xs leading-tight">{tech.name}</span>
                                                <span className="text-[9px] text-slate-400 font-bold uppercase">{tech.region} ({tech.department})</span>
                                            </div>
                                        </div>
                                        <span className="text-red-600 font-black text-sm whitespace-nowrap">{tech.ko} Cas</span>
                                    </div>
                                    <div className="flex flex-wrap gap-1 ml-9">
                                        {Object.entries(tech.koMotifs).sort(([,a]: any, [,b]: any) => b - a).slice(0, 3).map(([motif, count]: any) => (
                                            <span key={motif} className="text-[8px] font-bold uppercase px-1.5 py-0.5 bg-white border border-red-100 text-red-500 rounded">{motif} ({count})</span>
                                        ))}
                                    </div>
                                </div>
                            ))}
                            {topKOTechs.length === 0 && <div className="text-center text-slate-400 text-xs italic py-4">Aucune donnée KO disponible</div>}
                        </div>
                     </div>

                     {/* TOP COR AGENTS */}
                     <div id="block-top5-cor" className="bg-white rounded-3xl border border-amber-100 p-8 shadow-sm">
                        <h3 className="text-amber-600 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                            <span className="flex items-center gap-2"><span className="bg-amber-100 p-1 rounded">🔧</span> TOP 5 TECHNICIENS - CORRECTIONS (COR)</span>
                            <button onClick={() => handleDownloadImage('block-top5-cor', 'Top5_Tech_COR')} className="text-amber-300 hover:text-amber-600 transition-colors"><CameraIcon /></button>
                        </h3>
                        <div className="space-y-4">
                            {topCORTechs.map((tech: any, i: number) => (
                                <div key={i} className="bg-amber-50/50 rounded-xl p-4 border border-amber-100">
                                    <div className="flex justify-between items-center mb-2">
                                        <div className="flex items-center gap-3">
                                            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-500 text-white text-[10px] font-black shrink-0">{i + 1}</span>
                                            <div className="flex flex-col">
                                                <span className="text-slate-900 font-bold text-xs leading-tight">{tech.name}</span>
                                                <span className="text-[9px] text-slate-400 font-bold uppercase">{tech.region} ({tech.department})</span>
                                            </div>
                                        </div>
                                        <span className="text-amber-600 font-black text-sm whitespace-nowrap">{tech.cor} Cas</span>
                                    </div>
                                    <div className="flex flex-wrap gap-1 ml-9">
                                        {Object.entries(tech.corMotifs).sort(([,a]: any, [,b]: any) => b - a).slice(0, 3).map(([motif, count]: any) => (
                                            <span key={motif} className="text-[8px] font-bold uppercase px-1.5 py-0.5 bg-white border border-amber-100 text-amber-500 rounded">{motif} ({count})</span>
                                        ))}
                                    </div>
                                </div>
                            ))}
                            {topCORTechs.length === 0 && <div className="text-center text-slate-400 text-xs italic py-4">Aucune donnée COR disponible</div>}
                        </div>
                     </div>
                  </div>

                  <div id="block-matrix" className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                    <h3 className="text-indigo-600 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                        <span>MATRICE DES TYPES PAR STATUTS ET AGENCES</span>
                        <button onClick={() => handleDownloadImage('block-matrix', 'Matrice_Types')} className="text-indigo-200 hover:text-indigo-600 transition-colors"><CameraIcon /></button>
                    </h3>
                    <div className="overflow-hidden rounded-2xl border border-slate-100">
                        <table className="w-full text-left text-[11px]">
                            <thead className="bg-slate-900 text-white font-black uppercase">
                                <tr>
                                    <th className="px-5 py-4">AGENCE</th>
                                    <th className="px-5 py-4">TYPE</th>
                                    <th className="px-5 py-4 text-center">TOTAL</th>
                                    <th className="px-5 py-4 text-center text-emerald-400">CONF</th>
                                    <th className="px-5 py-4 text-center text-amber-400">COR PND</th>
                                    <th className="px-5 py-4 text-center text-blue-400">COR APR</th>
                                    <th className="px-5 py-4 text-center text-red-400">NC</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {Object.entries(dashboardData.matrix).sort().map(([region, types]: any) => (
                                    Object.entries(types).map(([typeName, s]: any, idx) => (
                                        <tr key={`${region}-${typeName}`} className="hover:bg-slate-50 transition-colors">
                                            {idx === 0 && <td rowSpan={Object.keys(types).length} className="px-5 py-4 font-black border-r border-slate-100 bg-slate-50/30">{region}</td>}
                                            <td className="px-5 py-4 font-bold text-slate-700">{typeName}</td>
                                            <td className="px-5 py-4 text-center font-black bg-slate-50/50">{s.total}</td>
                                            <td className="px-5 py-4 text-center font-bold text-emerald-600">
                                                {s.CONF} <span className="text-[9px] opacity-60">({((s.CONF/s.total)*100).toFixed(0)}%)</span>
                                            </td>
                                            <td className="px-5 py-4 text-center font-bold text-amber-600">
                                                {s['COR PND']} <span className="text-[9px] opacity-60">({((s['COR PND']/s.total)*100).toFixed(0)}%)</span>
                                            </td>
                                            <td className="px-5 py-4 text-center font-bold text-blue-600">
                                                {s['COR APR']} <span className="text-[9px] opacity-60">({((s['COR APR']/s.total)*100).toFixed(0)}%)</span>
                                            </td>
                                            <td className="px-5 py-4 text-center font-bold text-red-600">
                                                {s.NC} <span className="text-[9px] opacity-60">({((s.NC/s.total)*100).toFixed(0)}%)</span>
                                            </td>
                                        </tr>
                                    ))
                                ))}
                            </tbody>
                        </table>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-8">
                    <div id="block-repartition-ko" className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                      <h3 className="text-red-500 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                        <span className="flex items-center gap-2">RÉPARTITION KO PAR AGENCES</span>
                        <button onClick={() => handleDownloadImage('block-repartition-ko', 'Repartition_KO')} className="text-slate-300 hover:text-red-500 transition-colors"><CameraIcon /></button>
                      </h3>
                      <div className="overflow-hidden rounded-xl border border-slate-100">
                        <table className="w-full text-[11px] text-left">
                          <thead className="bg-slate-50 text-slate-500 font-black uppercase"><tr><th className="px-5 py-4">AGENCE</th><th className="px-5 py-4 text-center">KO</th><th className="px-5 py-4">MOTIFS CRITIQUES</th></tr></thead>
                          <tbody className="divide-y divide-slate-100">
                            {Object.entries(dashboardData.regions).sort(([,a]: any, [,b]: any) => b.ko - a.ko).map(([region, r]: any) => (
                              <tr key={region} className="hover:bg-slate-50 transition-colors">
                                <td className="px-5 py-4 text-slate-900 font-bold">{region}</td>
                                <td className="px-5 py-4 text-center text-red-500 font-black">{r.ko}</td>
                                <td className="px-5 py-4">
                                  <div className="flex flex-wrap gap-1.5">
                                    {Object.entries(r.koMotifs).sort(([,a]:any, [,b]:any) => b-a).slice(0,3).map(([m]) => (
                                      <span key={m} className="bg-red-50 text-red-600 px-2 py-0.5 rounded text-[8px] font-bold border border-red-100">{m}</span>
                                    ))}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div id="block-repartition-cor" className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                      <h3 className="text-amber-500 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                        <span className="flex items-center gap-2">RÉPARTITION COR PAR AGENCES</span>
                        <button onClick={() => handleDownloadImage('block-repartition-cor', 'Repartition_COR')} className="text-slate-300 hover:text-amber-500 transition-colors"><CameraIcon /></button>
                      </h3>
                      <div className="overflow-hidden rounded-xl border border-slate-100">
                        <table className="w-full text-[11px] text-left">
                          <thead className="bg-slate-50 text-slate-500 font-black uppercase"><tr><th className="px-5 py-4">AGENCE</th><th className="px-5 py-4 text-center">COR</th><th className="px-5 py-4">MOTIFS MODIFIÉS</th></tr></thead>
                          <tbody className="divide-y divide-slate-100">
                            {Object.entries(dashboardData.regions).sort(([,a]: any, [,b]: any) => b.cor - a.cor).map(([region, r]: any) => (
                              <tr key={region} className="hover:bg-slate-50 transition-colors">
                                <td className="px-5 py-4 text-slate-900 font-bold">{region}</td>
                                <td className="px-5 py-4 text-center text-amber-600 font-black">{r.cor}</td>
                                <td className="px-5 py-4">
                                  <div className="flex flex-wrap gap-1.5">
                                    {Object.entries(r.corMotifs).sort(([,a]:any, [,b]:any) => b-a).slice(0,3).map(([m]) => (
                                      <span key={m} className="bg-amber-50 text-amber-600 px-2 py-0.5 rounded text-[8px] font-bold border border-amber-100">{m}</span>
                                    ))}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  <div id="block-departments" className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
                    <h3 className="text-indigo-600 font-black text-xs uppercase tracking-widest mb-6 flex items-center justify-between">
                        <span>ANALYSE DÉTAILLÉE PAR DÉPARTEMENTS</span>
                        <button onClick={() => handleDownloadImage('block-departments', 'Analyse_Departements')} className="text-indigo-200 hover:text-indigo-600 transition-colors"><CameraIcon /></button>
                    </h3>
                    <div className="overflow-hidden rounded-2xl border border-slate-100">
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-500 text-[10px] font-black uppercase">
                          <tr><th className="px-6 py-4">DEPT</th><th className="px-6 py-4">AGENCE</th><th className="px-6 py-4 text-center">TOTAL</th><th className="px-6 py-4 text-center text-emerald-600">OK</th><th className="px-6 py-4 text-center text-red-600">KO</th><th className="px-6 py-4 text-center text-amber-600">COR</th><th className="px-6 py-4">MOTIFS FRÉQUENTS</th></tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {Object.entries(dashboardData.departments).sort(([a]:any, [b]:any) => parseInt(a)-parseInt(b)).map(([dept, d]: any) => (
                            <tr key={dept} className="hover:bg-slate-50 transition-colors">
                              <td className="px-6 py-4 text-slate-900 text-xs font-black">{dept}</td>
                              <td className="px-6 py-4 text-slate-500 text-[10px] uppercase font-bold">{d.region}</td>
                              <td className="px-6 py-4 text-center text-slate-400 text-xs">{d.total}</td>
                              <td className="px-6 py-4 text-center text-emerald-600 font-bold">{d.ok}</td>
                              <td className="px-6 py-4 text-center text-red-600 font-bold">{d.ko}</td>
                              <td className="px-6 py-4 text-center text-amber-600 font-bold">{d.cor}</td>
                              <td className="px-6 py-4">
                                <div className="flex flex-wrap gap-1 max-w-[250px]">
                                  {Object.entries(d.koMotifs).sort(([,a]:any, [,b]:any) => b-a).slice(0,2).map(([m]) => (
                                    <span key={m} className="bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded text-[8px] font-black border border-slate-200">{m}</span>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="pt-12 border-t-2 border-slate-200 mt-16">
                    <div id="block-agents" className="bg-white rounded-[40px] p-10 border border-slate-200 shadow-xl">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                        <div>
                          <h3 className="text-slate-900 font-black text-xl uppercase tracking-widest flex items-center gap-4">
                            <span>Performance et Conformité des Agents</span>
                            <button onClick={() => handleDownloadImage('block-agents', 'Performance_Agents')} className="text-slate-300 hover:text-slate-900 transition-colors"><CameraIcon /></button>
                          </h3>
                          <p className="text-slate-500 text-xs mt-1 font-medium tracking-wide">MESURE DE RIGUEUR : TRAITEMENTS CRM ET SYNTHÈSES TECHNIQUES</p>
                        </div>
                        <div className="flex flex-wrap items-center gap-4">
                          <div className="relative">
                            <input 
                              type="text" 
                              list="agents-list"
                              placeholder="Rechercher Agent..." 
                              value={agentSearch} 
                              onChange={(e) => setAgentSearch(e.target.value)}
                              className="pl-11 pr-10 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all w-80 shadow-inner"
                            />
                            <svg className="absolute left-4 top-4 text-slate-400" width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                            <datalist id="agents-list">
                                {Object.keys(dashboardData.agents).map(name => <option key={name} value={name} />)}
                            </datalist>
                          </div>
                          <button onClick={handleExportAgents} className="flex items-center gap-2 px-8 py-3.5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase hover:bg-black transition-all shadow-lg">Exporter Performance</button>
                        </div>
                      </div>
                      <div className="overflow-hidden rounded-3xl border border-slate-200 shadow-sm">
                        <table className="w-full text-left">
                          <thead className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest">
                            <tr>
                              <th className="px-4 py-7 cursor-pointer hover:bg-indigo-600 transition-colors" onClick={() => requestSort('name')}>AGENT</th>
                              <th className="px-4 py-7 text-center cursor-pointer hover:bg-indigo-600 transition-colors" onClick={() => requestSort('total')}>TOTAL</th>
                              <th className="px-4 py-7 text-center text-emerald-400">RACC</th>
                              <th className="px-4 py-7 text-center text-blue-400">PLP</th>
                              <th className="px-4 py-7 text-center text-amber-400">E2</th>
                              <th className="px-4 py-7 text-center text-purple-400">E3</th>
                              <th className="px-4 py-7 text-center text-emerald-600">OK</th>
                              <th className="px-4 py-7 text-center text-red-600">KO</th>
                              <th className="px-4 py-7 text-center text-amber-600">COR</th>
                              <th className="px-4 py-7 text-center">COMPLIANT</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 bg-white">
                            {filteredAgents.map((a: any) => {
                                const complianceRatio = (a.compliant / a.total) * 100;
                                return (
                                  <tr key={a.name} className="hover:bg-slate-50 transition-colors group text-[11px]">
                                    <td className="px-4 py-6 text-slate-900 font-black">{a.name}</td>
                                    <td className="px-4 py-6 text-center text-slate-600 font-bold bg-slate-50/50">{a.total}</td>
                                    <td className="px-4 py-6 text-center text-emerald-600 font-bold">{a.typeCounts.RACC}</td>
                                    <td className="px-4 py-6 text-center text-blue-600 font-bold">{a.typeCounts.PLP}</td>
                                    <td className="px-4 py-6 text-center text-amber-600 font-bold">{a.typeCounts.E2}</td>
                                    <td className="px-4 py-6 text-center text-purple-600 font-bold">{a.typeCounts.E3}</td>
                                    <td className="px-4 py-6 text-center text-emerald-600 font-black">{a.ok || 0}</td>
                                    <td className="px-4 py-6 text-center text-red-600 font-black">{a.ko || 0}</td>
                                    <td className="px-4 py-6 text-center text-amber-600 font-black">{a.cor || 0}</td>
                                    <td className="px-4 py-6 text-center">
                                      <div className="flex flex-col items-center gap-1">
                                        <div className={`px-2 py-1 rounded-full text-[9px] font-black border ${complianceRatio > 98 ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-red-50 text-red-600 border-red-100'}`}>
                                            {a.compliant} / {a.total}
                                        </div>
                                        <span className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">{complianceRatio.toFixed(0)}%</span>
                                      </div>
                                    </td>
                                  </tr>
                                );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center py-32 opacity-50">
                  <h3 className="text-slate-900 text-2xl font-black uppercase tracking-[0.3em] mb-3">En attente de fichier</h3>
                  <p className="text-slate-500 text-sm max-w-md font-medium leading-relaxed">Veuillez charger votre export CRM pour lancer les analyses de performance.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* IMPORT MODAL (2ème CONTACT) - RESTORED */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 animate-in zoom-in-95 duration-200">
            <h3 className="text-slate-800 font-black text-lg uppercase tracking-widest mb-4 flex items-center gap-2">
              <SynthesisIcon /> Import Synthèse
            </h3>
            <textarea
              ref={textareaRef}
              className="w-full h-32 bg-slate-50 border border-slate-200 rounded-xl p-3 text-[10px] font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4 resize-none shadow-inner"
              placeholder="Collez votre synthèse ici ([[...]])..."
              onChange={(e) => handleAnalysis(e.target.value)}
            />
            <div className="flex justify-end">
              <button onClick={() => setIsModalOpen(false)} className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[10px] font-black uppercase tracking-wide transition-colors">Annuler</button>
            </div>
          </div>
        </div>
      )}

      {/* FORM AREA */}
      <main className="flex-1 flex flex-col md:flex-row gap-1 p-1 min-h-0 w-full overflow-hidden">
        <div className="flex-1 overflow-y-auto pr-0.5 custom-scroll min-h-0">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-2 p-1">
            <Section 
              id="general"
              title="1. GÉNÉRAL" 
              icon={<GeneralIcon />} 
              isVisible={isBlockVisible(['contact', 'presta', 'Val_ROP', 'desserte'])} 
              baseColor="sky"
              isActive={activeSection === 'general'}
              onActivate={() => setActiveSection('general')}
            >
              {isFieldVisible('contact', type) && <ToggleGroup id="contact" label="CONTACT" variant="informative" value={formData.contact as ToggleValue} onChange={(v) => updateField('contact', v)} options={[{label: 'Avec', value: '1'}, {label: 'Sans', value: '0'}]} />}
              {isFieldVisible('presta', type) && <ToggleGroup id="presta" label="Chgt Presta" variant="informative" value={formData.presta as ToggleValue} onChange={(v) => updateField('presta', v)} options={OUI_NON_OPTS} description={DESCRIPTIONS.presta} />}
              {isFieldVisible('Val_ROP', type) && <ToggleGroup id="Val_ROP" label="Validation ROP" variant="informative" value={formData.Val_ROP as ToggleValue} onChange={(v) => updateField('Val_ROP', v)} options={OUI_NON_OPTS} description={DESCRIPTIONS.Val_ROP} />}
              {isFieldVisible('desserte', type) && <ToggleGroup id="desserte" label="Chgt Desserte" variant="informative" value={formData.desserte as ToggleValue} onChange={(v) => updateField('desserte', v)} options={OUI_NON_OPTS} description={DESCRIPTIONS.desserte} />}
            </Section>
            
            <Section 
              id="pm"
              title="2. PM" 
              icon={<PMIcon />} 
              isVisible={isBlockVisible(['pm_dechets', 'pm_comm_dechets', 'pm_cadrage', 'pm_ref_jarretieres', 'pm_mesure'])} 
              baseColor="emerald"
              isActive={activeSection === 'pm'}
              onActivate={() => setActiveSection('pm')}
            >
              {isFieldVisible('pm_dechets', type) && <ToggleGroup id="pm_dechets" label="DÉCHETS PM" value={formData.pm_dechets as ToggleValue} onChange={(v) => updateField('pm_dechets', v)} hasCor description={DESCRIPTIONS.pm_dechets} />}
              {isFieldVisible('pm_comm_dechets', type) && <DatalistInput isVisible={true} id="pm_comm_dechets" label="COMM DÉCHETS PM" value={formData.pm_comm_dechets || ''} onChange={(v) => updateField('pm_comm_dechets', v)} options={OPTIONS.commDechets} />}
              {isFieldVisible('pm_cadrage', type) && <ToggleGroup id="pm_cadrage" label="CADRAGE PM" value={formData.pm_cadrage as ToggleValue} onChange={(v) => updateField('pm_cadrage', v)} hasCor description={DESCRIPTIONS.pm_cadrage} />}
              {isFieldVisible('pm_ref_jarretieres', type) && <ToggleGroup id="pm_ref_jarretieres" label="RÉF JARR." value={formData.pm_ref_jarretieres as ToggleValue} onChange={(v) => updateField('pm_ref_jarretieres', v)} hasCor description={DESCRIPTIONS.pm_ref_jarretieres} />}
              <DatalistInput isVisible={isFieldVisible('pm_ref_jarretieres', type) && (formData.pm_ref_jarretieres === '0' || formData.pm_ref_jarretieres === 'Cor')} id="pm_comm_jarretieres" label="COMM JARR." value={formData.pm_comm_jarretieres || ''} onChange={(v) => updateField('pm_comm_jarretieres', v)} options={OPTIONS.commJarretieres} />
              {isFieldVisible('pm_mesure', type) && <ToggleGroup id="pm_mesure" label="MESURE PM" value={formData.pm_mesure as ToggleValue} onChange={(v) => updateField('pm_mesure', v)} hasCor description={DESCRIPTIONS.pm_mesure} />}
              <div className="col-span-full"><DatalistInput isVisible={isFieldVisible('pm_mesure', type) && (formData.pm_mesure === '0' || formData.pm_mesure === 'Cor')} id="pm_mesure_extra" label="DÉTAIL MESURE PM" value={formData.pm_mesure_extra || ''} onChange={(v) => updateField('pm_mesure_extra', v)} options={OPTIONS.mesureExtra} /></div>
            </Section>

            <Section 
              id="pto"
              title="3. PTO" 
              icon={<PTOIcon />} 
              isVisible={isBlockVisible(['pto_conf', 'pto_etiquette', 'pto_suspicion', 'pto_mesure_avant', 'pto_mesure', 'pto_photo', 'pto_cadrage'])} 
              baseColor="amber"
              isActive={activeSection === 'pto'}
              onActivate={() => setActiveSection('pto')}
            >
              {isFieldVisible('pto_conf', type) && <ToggleGroup id="pto_conf" label="PTO CONFORME" value={formData.pto_conf as ToggleValue} onChange={(v) => updateField('pto_conf', v)} hasCor description={DESCRIPTIONS.pto_conf} />}
              {isFieldVisible('pto_etiquette', type) && <ToggleGroup id="pto_etiquette" label="ÉTIQUETTE PTO" value={formData.pto_etiquette as ToggleValue} onChange={(v) => updateField('pto_etiquette', v)} hasCor description={DESCRIPTIONS.pto_etiquette} />}
              <DatalistInput isVisible={isFieldVisible('pto_etiquette', type) && (formData.pto_etiquette === '0' || formData.pto_etiquette === 'Cor')} id="pto_comm_etiquette" label="COMM ETIQ. PTO" value={formData.pto_comm_etiquette || ''} onChange={(v) => updateField('pto_comm_etiquette', v)} options={OPTIONS.commEtiquette} />
              {isFieldVisible('pto_suspicion', type) && <ToggleGroup id="pto_suspicion" label="SUSPICION FRAUDE" value={formData.pto_suspicion as ToggleValue} onChange={(v) => updateField('pto_suspicion', v)} hasCor description={DESCRIPTIONS.pto_suspicion} />}
              <DatalistInput isVisible={isFieldVisible('pto_suspicion', type) && (formData.pto_suspicion === '0' || formData.pto_suspicion === 'Cor')} id="pto_comm_suspicion" label="DÉTAIL SUSPICION" value={formData.pto_comm_suspicion || ''} onChange={(v) => updateField('pto_comm_suspicion', v)} options={OPTIONS.suspicionOpts} />
              {isFieldVisible('pto_mesure_avant', type) && <ToggleGroup id="pto_mesure_avant" label="Mesure PTO avant travaux" value={formData.pto_mesure_avant as ToggleValue} onChange={(v) => updateField('pto_mesure_avant', v)} hasCor description={DESCRIPTIONS.pto_mesure_avant} />}
              {isFieldVisible('pto_photo', type) && <ToggleGroup id="pto_photo" label="PHOTO PTO" value={formData.pto_photo as ToggleValue} onChange={(v) => updateField('pto_photo', v)} hasCor description={DESCRIPTIONS.pto_photo} />}
              <DatalistInput isVisible={isFieldVisible('pto_photo', type) && (formData.pto_photo === '0' || formData.pto_photo === 'Cor')} id="pto_comm_photo" label="COMM PHOTO PTO" value={formData.pto_comm_photo || ''} onChange={(v) => updateField('pto_comm_photo', v)} options={OPTIONS.commPhotoPtoPlp} />
              {isFieldVisible('pto_mesure', type) && <ToggleGroup id="pto_mesure" label="MESURE PTO" value={formData.pto_mesure as ToggleValue} onChange={(v) => updateField('pto_mesure', v)} hasCor description={DESCRIPTIONS.pto_mesure} />}
              <DatalistInput isVisible={isFieldVisible('pto_mesure', type) && (formData.pto_mesure === '0' || formData.pto_mesure === 'Cor')} id="pto_mesure_extra" label="DÉTAIL MESURE PTO" value={formData.pto_mesure_extra || ''} onChange={(v) => updateField('pto_mesure_extra', v)} options={OPTIONS.mesureExtra} />
              {isFieldVisible('pto_cadrage', type) && <ToggleGroup id="pto_cadrage" label="CADRAGE PTO" value={formData.pto_cadrage as ToggleValue} onChange={(v) => updateField('pto_cadrage', v)} hasCor description={DESCRIPTIONS.pto_cadrage} />}
            </Section>

            <Section 
              id="pbo"
              title="4. PBO" 
              icon={<PBOIcon />} 
              isVisible={isBlockVisible(['pbo_ref_cable', 'pbo_ref_pb', 'pbo_avant', 'pbo_apres', 'pbo_cadrage', 'pbo_mesure_e2'])} 
              baseColor="rose"
              isActive={activeSection === 'pbo'}
              onActivate={() => setActiveSection('pbo')}
            >
              {isFieldVisible('pbo_ref_cable', type) && <ToggleGroup id="pbo_ref_cable" label="RÉF CABLE" value={formData.pbo_ref_cable as ToggleValue} onChange={(v) => updateField('pbo_ref_cable', v)} hasCor description={DESCRIPTIONS.pbo_ref_cable} />}
              <DatalistInput isVisible={isFieldVisible('pbo_ref_cable', type) && (formData.pbo_ref_cable === '0' || formData.pbo_ref_cable === 'Cor')} id="pbo_comm_cable" label="COMM CABLE" value={formData.pbo_comm_cable || ''} onChange={(v) => updateField('pbo_comm_cable', v)} options={OPTIONS.commCable} />
              {isFieldVisible('pbo_ref_pb', type) && <ToggleGroup id="pbo_ref_pb" label="RÉF PB" value={formData.pbo_ref_pb as ToggleValue} onChange={(v) => updateField('pbo_ref_pb', v)} hasCor description={DESCRIPTIONS.pbo_ref_pb} />}
              <DatalistInput isVisible={isFieldVisible('pbo_ref_pb', type) && (formData.pbo_ref_pb === '0' || formData.pbo_ref_pb === 'Cor')} id="pbo_comm_pb" label="COMM RÉF" value={formData.pbo_comm_pb || ''} onChange={(v) => updateField('pbo_comm_pb', v)} options={OPTIONS.commRefPb} />
              {isFieldVisible('pbo_avant', type) && <ToggleGroup id="pbo_avant" label="PHOTO PBO AVANT" value={formData.pbo_avant as ToggleValue} onChange={(v) => updateField('pbo_avant', v)} hasCor description={DESCRIPTIONS.pbo_avant} />}
              <DatalistInput isVisible={isFieldVisible('pbo_avant', type) && (formData.pbo_avant === '0' || formData.pbo_avant === 'Cor')} id="pbo_comm_avant" label="COMM PBO AVANT" value={formData.pbo_comm_avant || ''} onChange={(v) => updateField('pbo_comm_avant', v)} options={OPTIONS.pbAvantOpts} />
              {isFieldVisible('pbo_apres', type) && <ToggleGroup id="pbo_apres" label="PHOTO PBO APRÈS" value={formData.pbo_apres as ToggleValue} onChange={(v) => updateField('pbo_apres', v)} hasCor description={DESCRIPTIONS.pbo_apres} />}
              <DatalistInput isVisible={isFieldVisible('pbo_apres', type) && (formData.pbo_apres === '0' || formData.pbo_apres === 'Cor')} id="pbo_comm_apres" label="COMM PBO APRÈS" value={formData.pbo_comm_apres || ''} onChange={(v) => updateField('pbo_comm_apres', v)} options={OPTIONS.pbApresOpts} />
              {isFieldVisible('pbo_cadrage', type) && <ToggleGroup id="pbo_cadrage" label="CADRAGE PB" value={formData.pbo_cadrage as ToggleValue} onChange={(v) => updateField('pbo_cadrage', v)} hasCor description={DESCRIPTIONS.pbo_cadrage} />}
              {isFieldVisible('pbo_mesure_e2', type) && <ToggleGroup id="pbo_mesure_e2" label="MESURE E2" isTriState={type !== AppType.PLP_E2} value={formData.pbo_mesure_e2 as ToggleValue} onChange={(v) => updateField('pbo_mesure_e2', v)} hasCor description={DESCRIPTIONS.pbo_mesure_e2} />}
            </Section>

            <Section 
              id="autre"
              title="5. AUTRE" 
              icon={<AutreIcon />} 
              isVisible={isBlockVisible(['autre_penetration', 'autre_geoloc', 'autre_voisinage', 'autre_voisin_perturbe', 'autre_sauvage', 'autre_nacelle', 'autre_photo_poteau'])} 
              baseColor="purple"
              isActive={activeSection === 'autre'}
              onActivate={() => setActiveSection('autre')}
            >
              {isFieldVisible('autre_penetration', type) && <ToggleGroup id="autre_penetration" label="PÉNÉTRATION" value={formData.autre_penetration as ToggleValue} onChange={(v) => updateField('autre_penetration', v)} hasCor description={DESCRIPTIONS.autre_penetration} />}
              {isFieldVisible('autre_geoloc', type) && <ToggleGroup id="autre_geoloc" label="GÉOLOCALISATION" value={formData.autre_geoloc as ToggleValue} onChange={(v) => updateField('autre_geoloc', v)} hasCor description={DESCRIPTIONS.autre_geoloc} />}
              {isFieldVisible('autre_voisinage', type) && <ToggleGroup id="autre_voisinage" label="CHECKVOISINAGE" value={formData.autre_voisinage as ToggleValue} onChange={(v) => updateField('autre_voisinage', v)} hasCor description={DESCRIPTIONS.autre_voisinage} />}
              <DatalistInput isVisible={isFieldVisible('autre_voisinage', type) && (formData.autre_voisinage === '0' || formData.autre_voisinage === 'Cor')} id="autre_comm_voisinage" label="COMM. CHECKV." value={formData.autre_comm_voisinage || ''} onChange={(v) => updateField('autre_comm_voisinage', v)} options={OPTIONS.voisinageOpts} />
              {isFieldVisible('autre_voisin_perturbe', type) && <ToggleGroup id="autre_voisin_perturbe" label="VOISIN PERTURBÉ" value={formData.autre_voisin_perturbe as ToggleValue} onChange={(v) => updateField('autre_voisin_perturbe', v)} options={[{label: 'Non', value: '0' as ToggleValue}, {label: 'Oui', value: '1' as ToggleValue}]} colorReversed={true} hasCor description={DESCRIPTIONS.autre_voisin_perturbe} />}
              {isFieldVisible('autre_sauvage', type) && <ToggleGroup id="autre_sauvage" label="INC" value={formData.autre_sauvage as ToggleValue} onChange={(v) => updateField('autre_sauvage', v)} options={[{label: 'Non', value: '0' as ToggleValue}, {label: 'Oui', value: '1' as ToggleValue}]} colorReversed={true} hasCor description={DESCRIPTIONS.autre_sauvage} />}
              {isFieldVisible('autre_nacelle', type) && <ToggleGroup id="autre_nacelle" label="NACELLE" isTriState value={formData.autre_nacelle as ToggleValue} onChange={(v) => updateField('autre_nacelle', v)} hasCor description={DESCRIPTIONS.autre_nacelle} />}
              {isFieldVisible('autre_photo_poteau', type) && <ToggleGroup id="autre_photo_poteau" label="POTEAU" isTriState value={formData.autre_photo_poteau as ToggleValue} onChange={(v) => updateField('autre_photo_poteau', v)} hasCor />}
            </Section>
          </div>
        </div>
        <div className="w-full md:w-[300px] xl:w-[340px] shrink-0 flex flex-col min-h-0">
          <div className="form-section !rounded-xl p-2 flex flex-col h-full overflow-hidden border-t-4 border-t-slate-800">
            <h3 className="flex items-center justify-center gap-2 font-black text-[10px] uppercase tracking-widest mb-1.5 pb-1 border-b text-slate-800"><SynthesisIcon /> SYNTHÈSE</h3>
            <textarea readOnly value={synthesisText} placeholder="En attente..." className="flex-1 w-full bg-slate-50/60 rounded-lg p-2 text-[9px] fira-code resize-none shadow-inner focus:outline-none transition-all mb-1.5 custom-scroll min-h-0" />
            
            <div className="mb-1.5 shrink-0">
              <label className="text-[0.7rem] font-[800] uppercase tracking-[0.05em] leading-[1.3] text-[#64748b] mb-1.5 block text-center">STATUT VALIDATION</label>
              <div className="grid grid-cols-2 gap-1 px-1">
                {(['CONF', 'COR PND', 'COR APR', 'NC'] as ValidationStatus[]).map((status) => {
                  const isActive = formData.status === status;
                  let pillStyle = "border-2 border-slate-200 text-slate-400 bg-white";
                  if (isActive) {
                    if (status === 'CONF') pillStyle = "border-2 border-emerald-500 text-emerald-600 bg-emerald-50 shadow-md scale-105";
                    else if (status === 'COR PND') pillStyle = "border-2 border-amber-500 text-amber-600 bg-amber-50 shadow-md scale-105";
                    else if (status === 'COR APR') pillStyle = "border-2 border-blue-500 text-blue-600 bg-blue-50 shadow-md scale-105";
                    else if (status === 'NC') pillStyle = "border-2 border-red-500 text-red-600 bg-red-50 shadow-md scale-105";
                  }
                  return (
                    <label key={status} className="cursor-pointer">
                      <input type="radio" name="validation_status" className="hidden" checked={isActive} onChange={() => updateField('status', status)} />
                      <span className={`flex items-center justify-center py-2 rounded-xl text-[8px] font-black uppercase transition-all duration-300 ${pillStyle}`}>{status}</span>
                    </label>
                  );
                })}
              </div>
            </div>
            <div className="flex gap-1.5 shrink-0 mt-2">
              <button onClick={() => { if (isFormComplete) { navigator.clipboard.writeText(synthesisText); Swal.fire({ icon: 'success', title: 'Copié !', timer: 1000, showConfirmButton: false, toast: true, position: 'top-end' }); } }} disabled={!isFormComplete} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-black text-[10px] uppercase text-white shadow-sm transition-all active:scale-95 btn-accent ${!isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}><CopyIcon /> COPIER</button>
              <button onClick={handleReset} className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-white bg-red-600 shadow-sm active:scale-95 hover:bg-red-700 transition-colors"><ResetIcon /></button>
            </div>
          </div>
        </div>
      </main>
      <footer className="bg-black/10 py-1 text-center text-[7px] font-black uppercase tracking-[0.4em] shrink-0 border-t border-white/5 opacity-30">VCR OK v4.0</footer>
    </div>
  );
};

export default App;