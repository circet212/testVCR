
import React from 'react';
import { ToggleValue } from '../types';

interface TooltipProps {
  text: string;
}

const Tooltip: React.FC<TooltipProps> = ({ text }) => {
  if (!text) return null;
  return (
    <div className="tooltip-trigger relative inline-block ml-1 group/tooltip">
      <svg className="w-3.5 h-3.5 text-slate-400 hover:text-[var(--app-accent)] transition-colors cursor-help" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      <div className="tooltip-box absolute bottom-full left-1/2 -translate-x-1/2 mb-2 text-center z-[9999] opacity-0 invisible group-hover/tooltip:opacity-100 group-hover/tooltip:visible pointer-events-none transition-all duration-200 translate-y-2 group-hover/tooltip:translate-y-0">
        <div className="relative bg-[#1e293b] text-white p-2 rounded-lg shadow-xl text-[10px] font-semibold min-w-[150px] max-w-[250px] leading-tight whitespace-normal">
          {text}
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-[6px] border-transparent border-t-[#1e293b]"></div>
        </div>
      </div>
    </div>
  );
};

interface ToggleGroupProps {
  id: string;
  label: string;
  value: ToggleValue;
  onChange: (val: ToggleValue) => void;
  options?: { label: string; value: ToggleValue }[];
  isTriState?: boolean;
  hasCor?: boolean;
  colorReversed?: boolean; 
  disabled?: boolean;
  description?: string;
  variant?: 'default' | 'informative';
}

export const ToggleGroup: React.FC<ToggleGroupProps> = ({ 
  label, 
  value, 
  onChange, 
  isTriState = false,
  hasCor = false,
  colorReversed = false,
  disabled = false,
  description = "",
  variant = 'default',
  options = [
    { label: '1', value: '1' },
    { label: '0', value: '0' }
  ]
}) => {
  let finalOptions = [...options];
  if (hasCor) finalOptions.push({ label: 'Cor', value: 'Cor' });
  if (isTriState) finalOptions.push({ label: 'NA', value: 'NA' });

  return (
    <div className={`flex flex-col gap-1 mb-1 group ${disabled ? 'pointer-events-none opacity-80' : ''}`}>
      <div className="flex items-center">
        <label className={`text-[0.7rem] font-[800] uppercase tracking-[0.05em] leading-[1.3] text-[#64748b] transition-colors ${disabled ? 'opacity-50' : 'opacity-100'}`}>
          {label}{!disabled && <span className="text-red-500 ml-0.5">*</span>}
        </label>
        {description && <Tooltip text={description} />}
      </div>
      <div className={`toggle-container flex rounded-lg overflow-hidden border border-black/5 shadow-sm h-8 w-[95%] shrink-0 ${disabled ? 'bg-slate-200/50' : 'bg-black/5'}`}>
        {finalOptions.map((opt) => {
          const isActive = value === opt.value;
          let activeClass = "";
          
          if (isActive) {
            if (opt.value === 'Cor') {
              activeClass = "bg-amber-500 text-white shadow-inner scale-105 z-10";
            } else if (variant === 'informative') {
              if (opt.value === '1') activeClass = "bg-blue-600 text-white shadow-md scale-105 z-10";
              else if (opt.value === '0') activeClass = "bg-white text-blue-600 shadow-md scale-105 z-10 ring-1 ring-blue-100";
              else activeClass = "bg-slate-400 text-white shadow-inner scale-105 z-10";
            } else if (colorReversed) {
              if (opt.value === '0') activeClass = "bg-emerald-500 text-white shadow-inner scale-105 z-10";
              else if (opt.value === '1') activeClass = "bg-red-500 text-white shadow-inner scale-105 z-10";
              else activeClass = "bg-slate-500 text-white shadow-inner scale-105 z-10";
            } else {
              if (opt.value === '1') activeClass = "bg-emerald-500 text-white shadow-inner scale-105 z-10";
              else if (opt.value === '0') activeClass = "bg-red-500 text-white shadow-inner scale-105 z-10";
              else activeClass = "bg-slate-500 text-white shadow-inner scale-105 z-10";
            }
          } else {
            activeClass = "opacity-40";
          }

          return (
            <button
              key={opt.value}
              type="button"
              disabled={disabled}
              onClick={() => !disabled && onChange(opt.value)}
              className={`flex-1 text-[9px] font-black uppercase tracking-tighter transition-all duration-200 ${disabled ? '' : 'active:scale-90'} ${activeClass}`}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
};

interface DatalistInputProps {
  id: string;
  label: string;
  value: string;
  onChange: (val: string) => void;
  options: string[];
  isVisible: boolean;
  description?: string;
}

export const DatalistInput: React.FC<DatalistInputProps> = ({ label, value, onChange, options, isVisible, description = "" }) => {
  if (!isVisible) return null;

  return (
    <div className="flex flex-col gap-1 mb-1 animate-in fade-in slide-in-from-top-1 duration-200">
      <div className="flex items-center">
        <label className="text-[0.7rem] font-[800] uppercase tracking-[0.05em] leading-[1.3] text-[#64748b] opacity-100">{label}<span className="text-red-500 ml-0.5">*</span></label>
        {description && <Tooltip text={description} />}
      </div>
      <input
        type="text"
        list={`list-${label}`}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Choisir..."
        className="w-full rounded-lg px-2 py-1 text-[10px] font-bold focus:outline-none focus:ring-1 focus:ring-[var(--app-accent)] transition-all shadow-inner border border-black/5 bg-white/80"
      />
      <datalist id={`list-${label}`}>
        {options.map((opt, i) => (
          <option key={i} value={opt} />
        ))}
      </datalist>
    </div>
  );
};
