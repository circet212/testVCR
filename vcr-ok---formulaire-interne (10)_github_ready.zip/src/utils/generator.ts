import { AppType, FormData } from '../types';

/**
 * FIXED SEQUENCE FOR TECHNICAL SIGNATURE
 */
const FIXED_SIGNATURE_ORDER = [
  { key: 'contact', label: 'CONTACT' },
  { key: 'presta', label: 'CHGT PRESTA' },
  { key: 'Val_ROP', label: 'VALIDATION ROP' },
  { key: 'desserte', label: 'CHGT DESSERTE' },
  { key: 'pm_dechets', label: 'DÉCHETS PM' },
  { key: 'pm_cadrage', label: 'CADRAGE PM' },
  { key: 'pm_ref_jarretieres', label: 'RÉF JARR.' },
  { key: 'pm_mesure', label: 'MESURE PM' },
  { key: 'pto_conf', label: 'PTO CONFORME' },
  { key: 'pto_etiquette', label: 'ÉTIQUETTE PTO' },
  { key: 'pto_suspicion', label: 'SUSPICION FRAUDE' },
  { key: 'pto_mesure_avant', label: 'MESURE PTO AVANT' },
  { key: 'pto_mesure', label: 'MESURE PTO' },
  { key: 'pto_photo', label: 'PHOTO PTO' },
  { key: 'pto_cadrage', label: 'CADRAGE PTO' },
  { key: 'pbo_ref_cable', label: 'RÉF CABLE' },
  { key: 'pbo_ref_pb', label: 'RÉF PB' },
  { key: 'pbo_avant', label: 'PHOTO PBO AVANT' },
  { key: 'pbo_apres', label: 'PHOTO PBO APRÈS' },
  { key: 'pbo_cadrage', label: 'CADRAGE PB' },
  { key: 'pbo_mesure_e2', label: 'MESURE E2' },
  { key: 'autre_penetration', label: 'PÉNÉTRATION' },
  { key: 'autre_geoloc', label: 'GÉOLOCALISATION' },
  { key: 'autre_voisinage', label: 'CHECKVOISINAGE' },
  { key: 'autre_voisin_perturbe', label: 'VOISIN PERTURBÉ' },
  { key: 'autre_sauvage', label: 'INC' },
  { key: 'autre_nacelle', label: 'NACELLE' },
  { key: 'autre_photo_poteau', label: 'POTEAU' }
];

const SIGNATURE_COMMENT_MAP: Record<string, string> = {
  'pm_dechets': 'pm_comm_dechets',
  'pm_ref_jarretieres': 'pm_comm_jarretieres',
  'pm_mesure': 'pm_mesure_extra',
  'pto_etiquette': 'pto_comm_etiquette',
  'pto_suspicion': 'pto_comm_suspicion',
  'pto_mesure': 'pto_mesure_extra',
  'pto_photo': 'pto_comm_photo',
  'pbo_ref_cable': 'pbo_comm_cable',
  'pbo_ref_pb': 'pbo_comm_pb',
  'pbo_avant': 'pbo_comm_avant',
  'pbo_apres': 'pbo_comm_apres',
  'autre_voisinage': 'autre_comm_voisinage'
};

const formatUserSignature = (fullName: string): string => {
  if (!fullName || !fullName.trim()) return "";
  
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 0) return "";
  
  // Prénom : 1er mot
  const firstName = parts[0];
  // Nom : le reste (ou rien si un seul mot)
  const lastName = parts.length > 1 ? parts.slice(1).join("") : "";

  // Traitement Prénom : 2 premières lettres, 1ere Maj, 2eme min
  const f = firstName.substring(0, 2);
  const fFormatted = f.charAt(0).toUpperCase() + (f.length > 1 ? f.charAt(1).toLowerCase() : "");

  // Traitement Nom : 3 premières lettres, tout en Maj
  // Si pas de nom de famille, on ne met rien après le point ou on adapte
  let lFormatted = "";
  if (lastName) {
      lFormatted = lastName.substring(0, 3).toUpperCase();
  } else if (firstName.length > 2) {
      // Fallback si l'utilisateur n'a mis qu'un seul nom long
      lFormatted = firstName.substring(2, 5).toUpperCase();
  }

  return `${fFormatted}.${lFormatted}`;
};

export const generateSynthesis = (type: AppType, data: FormData, importedContact?: string, userName?: string, importedSignature?: string): string => {
  const validationStatus = data['status'] || 'CONF';
  const f = (id: string) => data[id] || 'NA';

  const typeLabel = type === AppType.RACC ? 'RACC' : type === AppType.PLP_E3 ? 'E3' : type === AppType.PLP_E2 ? 'E2' : 'PLP';

  const resumeParts: string[] = [];
  const tagsParts: string[] = [];

  resumeParts.push(`TYPE : ${typeLabel}`);
  resumeParts.push(`STATUT VALIDATION : ${validationStatus}`);
  tagsParts.push(typeLabel);
  tagsParts.push(validationStatus);

  FIXED_SIGNATURE_ORDER.forEach(item => {
    const key = item.key;
    const label = item.label;
    const val = f(key);
    
    let displayVal = val === 'NA' ? 'NA' : (val === 'Cor' ? 'Cor' : (val === '1' ? '1' : '0'));
    
    if (key === 'contact') {
      displayVal = val === 'NA' ? 'NA' : (val === '1' ? 'Avec' : 'Sans');
    } else if (['presta', 'Val_ROP', 'desserte', 'autre_voisin_perturbe', 'autre_sauvage'].includes(key)) {
      if (val === 'Cor') displayVal = 'Cor';
      else displayVal = val === 'NA' ? 'NA' : (val === '1' ? 'Oui' : 'Non');
    }

    const commentKey = SIGNATURE_COMMENT_MAP[key];
    const comment = commentKey ? data[commentKey] : null;

    let resumeVal = displayVal;
    if (comment && comment.trim() !== '') {
      if (key === 'pm_dechets' || val === '0' || val === 'Cor') {
        resumeVal += ` (${comment.trim()})`;
      }
    }
    
    resumeParts.push(`${label} : ${resumeVal}`);
    tagsParts.push(resumeVal);
  });

  const typeTitle = type === AppType.RACC ? 'RACCORDEMENT' : type === AppType.PLP_E3 ? 'PLP E3' : type === AppType.PLP_E2 ? 'PLP E2' : 'PLP';
  
  // LOGIQUE DE SIGNATURE ET CONTACT
  const currentContactLabel = data['contact'] === '1' ? 'Avec' : 'Sans';
  const currentAbbrev = userName ? formatUserSignature(userName) : '';
  
  let contactLine = '';

  if (importedContact) {
    // Cas 2ème contact
    const importedLabel = importedContact === '1' ? 'Avec' : (importedContact === '0' ? 'Sans' : importedContact);
    // Signature C1 (Importée)
    const sig1 = importedSignature ? ` (${importedSignature})` : '';
    // Signature C2 (Actuelle)
    const sig2 = currentAbbrev ? ` (${currentAbbrev})` : '';
    
    contactLine = `C1${sig1} : ${importedLabel} / C2${sig2} : ${currentContactLabel}`;
  } else {
    // Cas 1er contact
    const sig1 = currentAbbrev ? ` (${currentAbbrev})` : '';
    contactLine = `C1${sig1} : ${currentContactLabel}`;
  }

  let output = `*** CR ${typeTitle} ***\n${contactLine}\n${validationStatus}\n`;

  const addLine = (label: string, id: string, format: 'tri' | 'contact' | 'ouinon' | 'voisin' = 'tri', commId?: string) => {
    const val = f(id);
    if (val === 'NA') return "";
    
    let displayVal = val;
    if (val === 'Cor') {
      displayVal = 'Cor';
    } else if (format === 'contact') {
      displayVal = (val === '1' ? 'Avec' : 'Sans');
    } else if (format === 'ouinon' || format === 'voisin') {
      displayVal = (val === '1' ? 'Oui' : 'Non');
    } else {
      displayVal = (val === '1' ? '1' : '0');
    }
    
    const comm = commId ? data[commId] : null;
    return `${label} : ${displayVal}${comm && comm.trim() !== '' ? ` (${comm.trim()})` : ''}\n`;
  };

  let genContent = "";
  // Contact est déjà géré dans l'en-tête, on peut le masquer ici ou le laisser. 
  // Dans l'ancienne version il était aussi dans le corps. On le laisse pour la cohérence des parsers.
  genContent += addLine('CONTACT', 'contact', 'contact');
  genContent += addLine('Chgt Presta', 'presta', 'ouinon');
  genContent += addLine('Validation ROP', 'Val_ROP', 'ouinon');
  genContent += addLine('Chgt Desserte', 'desserte', 'ouinon');
  if (genContent) output += genContent;

  let pmContent = "";
  pmContent += addLine('Déchets PM', 'pm_dechets', 'tri', 'pm_comm_dechets');
  if (f('pm_cadrage') !== '1') pmContent += addLine('Cadrage PM', 'pm_cadrage', 'tri');
  if (f('pm_ref_jarretieres') !== '1') pmContent += addLine('Réf JARR.', 'pm_ref_jarretieres', 'tri', 'pm_comm_jarretieres');
  if (f('pm_mesure') !== '1') pmContent += addLine('Mesure PM', 'pm_mesure', 'tri', 'pm_mesure_extra');
  if (pmContent) output += `------------------------- PM -------------------------\n${pmContent}`;

  let ptoContent = "";
  if (f('pto_conf') !== '1') ptoContent += addLine('PTO Conforme', 'pto_conf', 'tri');
  if (f('pto_etiquette') !== '1') ptoContent += addLine('Étiquette PTO', 'pto_etiquette', 'tri', 'pto_comm_etiquette');
  if (f('pto_suspicion') !== '1') ptoContent += addLine('Suspicion fraude', 'pto_suspicion', 'tri', 'pto_comm_suspicion');
  if (f('pto_mesure_avant') !== '1') ptoContent += addLine('Mesure PTO avant', 'pto_mesure_avant', 'tri');
  if (f('pto_mesure') !== '1') ptoContent += addLine('Mesure PTO', 'pto_mesure', 'tri', 'pto_mesure_extra');
  if (f('pto_photo') !== '1') ptoContent += addLine('Photo PTO', 'pto_photo', 'tri', 'pto_comm_photo');
  if (f('pto_cadrage') !== '1') ptoContent += addLine('Cadrage PTO', 'pto_cadrage', 'tri');
  if (ptoContent) output += `------------------------- PTO -------------------------\n${ptoContent}`;

  let pboContent = "";
  if (f('pbo_ref_cable') !== '1') pboContent += addLine('Réf Cable', 'pbo_ref_cable', 'tri', 'pbo_comm_cable');
  if (f('pbo_ref_pb') !== '1') pboContent += addLine('Réf PB', 'pbo_ref_pb', 'tri', 'pbo_comm_pb');
  if (f('pbo_avant') !== '1') pboContent += addLine('Photo PBO avant', 'pbo_avant', 'tri', 'pbo_comm_avant');
  if (f('pbo_apres') !== '1') pboContent += addLine('Photo PBO après', 'pbo_apres', 'tri', 'pbo_comm_apres');
  if (f('pbo_cadrage') !== '1') pboContent += addLine('Cadrage PB', 'pbo_cadrage', 'tri');
  if (f('pbo_mesure_e2') !== '1') pboContent += addLine('Mesure E2', 'pbo_mesure_e2', 'tri');
  if (pboContent) output += `------------------------- PBO -------------------------\n${pboContent}`;

  let autreContent = "";
  if (f('autre_penetration') !== '1') autreContent += addLine('Pénétration', 'autre_penetration', 'tri');
  if (f('autre_geoloc') !== '1') autreContent += addLine('Géolocalisation', 'autre_geoloc', 'tri');
  if (f('autre_voisinage') !== '1') autreContent += addLine('CheckVoisinage', 'autre_voisinage', 'tri', 'autre_comm_voisinage');
  if (f('autre_voisin_perturbe') !== '0') autreContent += addLine('Voisin Perturbé', 'autre_voisin_perturbe', 'voisin');
  if (f('autre_sauvage') !== '0') autreContent += addLine('INC', 'autre_sauvage', 'ouinon');
  if (f('autre_nacelle') !== '1') autreContent += addLine('Nacelle', 'autre_nacelle', 'tri');
  if (f('autre_photo_poteau') !== '1') autreContent += addLine('Poteau', 'autre_photo_poteau', 'tri');
  if (autreContent) output += `------------------------- AUTRE -------------------------\n${autreContent}`;

  const resumeHeader = `------------------------- RESUME -------------------------`;
  const tagsHeader = ``;
  const resumeLine = `[[${resumeParts.join('\\\\')}]]`;
  const tagsLine = `【${tagsParts.join('\\')}】`;
  
  return `${tagsHeader}\n${tagsLine}\n${resumeHeader}\n${resumeLine}\n${output.trim()}`.replace(/\n{3,}/g, '\n\n');
};